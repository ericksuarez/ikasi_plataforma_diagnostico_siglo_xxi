"use strict";
var Course = (function () {
    function Course() {
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=course.js.map