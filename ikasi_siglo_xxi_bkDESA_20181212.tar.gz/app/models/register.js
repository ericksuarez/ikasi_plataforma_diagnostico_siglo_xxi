"use strict";
var Register = (function () {
    function Register() {
    }
    return Register;
}());
exports.Register = Register;
//# sourceMappingURL=register.js.map