export class SkillCenturyCategory{
	constructor(
		public skill_century_category_id: number,
		public name: string,
	) {}
}