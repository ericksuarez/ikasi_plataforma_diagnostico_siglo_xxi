export class AnswerQuestionCentury{
    public name;
    public questionId;
}