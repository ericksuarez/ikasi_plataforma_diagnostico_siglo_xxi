export class Email {
    public email: string;
    public emailRepeat: string;
}