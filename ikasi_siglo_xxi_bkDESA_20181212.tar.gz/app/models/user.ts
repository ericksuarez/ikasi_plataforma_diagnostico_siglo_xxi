export class User {
    constructor(
        public id: string,
        public email: string,
        public status: string,
        public password: string
    ) { }
}