export class PasswordReset {
    public id: string;
    public token: string;
    public password: string;
    public password_repeat: string;
}