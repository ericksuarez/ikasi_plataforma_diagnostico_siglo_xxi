"use strict";
var AnswerQuestionCentury = (function () {
    function AnswerQuestionCentury() {
    }
    return AnswerQuestionCentury;
}());
exports.AnswerQuestionCentury = AnswerQuestionCentury;
//# sourceMappingURL=AnswerQuestionCentury.js.map