export class Dimension {
    public name: string;
    public teacher_function: string;
    public education_level: string;
}