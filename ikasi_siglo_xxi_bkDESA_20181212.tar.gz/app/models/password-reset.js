"use strict";
var PasswordReset = (function () {
    function PasswordReset() {
    }
    return PasswordReset;
}());
exports.PasswordReset = PasswordReset;
//# sourceMappingURL=password-reset.js.map