export class IneeEvaluation {
    public education_level: string;
    public teacher_function: string;
    public dimension: string;
    public parameter: string;
    public indicator: string;
    public reagent_base: string;
    public argumentation: string;
    public reference: string;
    public answerCollection: any;
    public answer: string;
    public correctAnswer: string;
    public typeImport: any;
}