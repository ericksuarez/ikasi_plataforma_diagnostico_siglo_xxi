export class SkillQuestionCentury{
	constructor(
		public id:number,
		public area_id: number,
		public category_id: number,
		public name: string		
	) {}
}