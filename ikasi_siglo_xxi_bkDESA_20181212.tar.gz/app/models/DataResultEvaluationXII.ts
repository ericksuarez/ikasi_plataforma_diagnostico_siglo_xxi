export class DataResultEvaluationXII {
    public data =[];
    public label = "";
}