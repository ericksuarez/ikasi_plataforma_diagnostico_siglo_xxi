export class SkillArea {

    constructor(public skill_century_id: number,
                public name: string,
                public min_vulnerable: number,
                public max_vulnerable: number,
                public min_competent: number,
                public max_competent: number,
                public min_optimum: number,
                public max_optimum: number) {
    }

}