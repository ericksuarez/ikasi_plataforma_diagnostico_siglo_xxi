"use strict";
var User = (function () {
    function User(id, email, status, password) {
        this.id = id;
        this.email = email;
        this.status = status;
        this.password = password;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=user.js.map