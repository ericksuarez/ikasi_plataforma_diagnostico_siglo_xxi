"use strict";
var CatalogForm = (function () {
    function CatalogForm() {
    }
    return CatalogForm;
}());
exports.CatalogForm = CatalogForm;
//# sourceMappingURL=catalog_form.js.map