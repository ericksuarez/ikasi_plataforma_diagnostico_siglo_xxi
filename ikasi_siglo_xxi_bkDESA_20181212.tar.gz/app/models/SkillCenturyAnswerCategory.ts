export class SkillCenturyAnswerCategory{
	constructor(
		public id: number,
		public category_id:number,
        public name: string,
        public value: number,
		) {}
}