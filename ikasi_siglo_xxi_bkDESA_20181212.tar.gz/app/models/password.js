"use strict";
var Password = (function () {
    function Password() {
    }
    return Password;
}());
exports.Password = Password;
//# sourceMappingURL=password.js.map