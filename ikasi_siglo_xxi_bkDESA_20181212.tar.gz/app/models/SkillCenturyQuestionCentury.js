"use strict";
var SkillQuestionCentury = (function () {
    function SkillQuestionCentury(id, area_id, category_id, name) {
        this.id = id;
        this.area_id = area_id;
        this.category_id = category_id;
        this.name = name;
    }
    return SkillQuestionCentury;
}());
exports.SkillQuestionCentury = SkillQuestionCentury;
//# sourceMappingURL=SkillCenturyQuestionCentury.js.map