export class Course {
    public name: string;
    public description: string;
    public teacher_function: string;
    public education_level: string;
    public specialty: string;
    public link: string;
    public type_suggestion: number;
    public skill_century: string;
    public area_century: any;
    public dimension;
}