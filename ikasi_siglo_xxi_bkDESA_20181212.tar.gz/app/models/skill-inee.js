"use strict";
var SkillIne = (function () {
    function SkillIne() {
    }
    return SkillIne;
}());
exports.SkillIne = SkillIne;
//# sourceMappingURL=skill-inee.js.map