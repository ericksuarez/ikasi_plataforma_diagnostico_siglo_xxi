"use strict";
var Dimension = (function () {
    function Dimension() {
    }
    return Dimension;
}());
exports.Dimension = Dimension;
//# sourceMappingURL=dimension.js.map