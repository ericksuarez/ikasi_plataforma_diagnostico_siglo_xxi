export class SkillCentury {
    constructor(public id: string,
                public name: string) {
    }
}