export class CatalogForm {
    public name: string;
}