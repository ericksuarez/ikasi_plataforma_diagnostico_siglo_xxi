"use strict";
var DataResultEvaluationXII = (function () {
    function DataResultEvaluationXII() {
        this.data = [];
        this.label = "";
    }
    return DataResultEvaluationXII;
}());
exports.DataResultEvaluationXII = DataResultEvaluationXII;
//# sourceMappingURL=DataResultEvaluationXII.js.map