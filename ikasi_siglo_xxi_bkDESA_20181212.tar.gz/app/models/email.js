"use strict";
var Email = (function () {
    function Email() {
    }
    return Email;
}());
exports.Email = Email;
//# sourceMappingURL=email.js.map