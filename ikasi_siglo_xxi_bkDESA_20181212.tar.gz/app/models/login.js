"use strict";
var Login = (function () {
    function Login() {
    }
    return Login;
}());
exports.Login = Login;
//# sourceMappingURL=login.js.map