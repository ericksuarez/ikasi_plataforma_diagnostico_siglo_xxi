"use strict";
var SkillCentury = (function () {
    function SkillCentury(id, name) {
        this.id = id;
        this.name = name;
    }
    return SkillCentury;
}());
exports.SkillCentury = SkillCentury;
//# sourceMappingURL=SkillCentury.js.map