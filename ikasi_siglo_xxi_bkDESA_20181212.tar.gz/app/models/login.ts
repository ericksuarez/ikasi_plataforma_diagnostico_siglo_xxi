export class Login {
    public email: string;
    public password: string;
}