export class SkillIne {
    public typeImport;
    public education_level: string;
    public teacher_function: string;
    public dimension: string;
    public parameter: string;
}