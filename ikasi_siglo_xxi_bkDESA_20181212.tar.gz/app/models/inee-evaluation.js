"use strict";
var IneeEvaluation = (function () {
    function IneeEvaluation() {
    }
    return IneeEvaluation;
}());
exports.IneeEvaluation = IneeEvaluation;
//# sourceMappingURL=inee-evaluation.js.map