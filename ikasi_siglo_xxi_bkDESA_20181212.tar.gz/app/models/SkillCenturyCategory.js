"use strict";
var SkillCenturyCategory = (function () {
    function SkillCenturyCategory(skill_century_category_id, name) {
        this.skill_century_category_id = skill_century_category_id;
        this.name = name;
    }
    return SkillCenturyCategory;
}());
exports.SkillCenturyCategory = SkillCenturyCategory;
//# sourceMappingURL=SkillCenturyCategory.js.map