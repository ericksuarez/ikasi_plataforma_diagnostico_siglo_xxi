export class Register {
    public curp: string;
    public fullname: string;
    public teacher_function: string;
    public education_level: string;
    public specialty: string;
    public email: string;
    public password: string;
}