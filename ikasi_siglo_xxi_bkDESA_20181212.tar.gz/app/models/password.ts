export class Password {
    public oldPassword: string;
    public newPassword: string;
    public repeatNewPassword: string;
}