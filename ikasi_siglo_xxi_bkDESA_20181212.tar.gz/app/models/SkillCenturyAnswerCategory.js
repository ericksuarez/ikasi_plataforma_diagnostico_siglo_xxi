"use strict";
var SkillCenturyAnswerCategory = (function () {
    function SkillCenturyAnswerCategory(id, category_id, name, value) {
        this.id = id;
        this.category_id = category_id;
        this.name = name;
        this.value = value;
    }
    return SkillCenturyAnswerCategory;
}());
exports.SkillCenturyAnswerCategory = SkillCenturyAnswerCategory;
//# sourceMappingURL=SkillCenturyAnswerCategory.js.map