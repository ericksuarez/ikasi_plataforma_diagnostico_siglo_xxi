export const ENVIRONMENT = {
    production: true
}