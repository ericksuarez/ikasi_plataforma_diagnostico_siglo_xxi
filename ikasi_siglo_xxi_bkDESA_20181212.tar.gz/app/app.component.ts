import {Component, OnInit}      from '@angular/core';
import {AuthService} from "./services/auth.service";

declare let jQuery: any;

@Component({
    selector: 'my-app',
    templateUrl: 'app/views/layout.html',
})

export class AppComponent implements OnInit {
    public isAdmin;
    public profile;
    public isLoggedIn;

    constructor(private authService: AuthService) {
        this.isAdmin = authService.isAdmin();
        this.profile = authService.getProfile();
        this.isLoggedIn = authService.isLoggedIn();
    }

    ngOnInit(): void {
        if (jQuery("#back").length) {
            // Back To Top Icon
            this.callBackToTop();
        }
    }

    private callBackToTop(): void {
        let offset = 250; // Offset after which Back To Top button will be visible
        let duration = 1000; // Time duration in which the page scrolls back up.

        //noinspection TypeScriptValidateJSTypes
        jQuery(window).scroll(function () {
            //noinspection TypeScriptValidateJSTypes
            if (jQuery(this).scrollTop() > offset) {
                //noinspection TypeScriptUnresolvedFunction
                jQuery('#back').fadeIn(500);
            } else {
                //noinspection TypeScriptUnresolvedFunction
                jQuery('#back').fadeOut(500);
            }
        });

        jQuery('#back').click(function (event) {
            event.preventDefault();
            jQuery('html, body').animate({scrollTop: 0}, duration);
            return false;
        });
    }
}
