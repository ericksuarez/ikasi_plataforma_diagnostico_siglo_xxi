import {Component}          from '@angular/core';
import {Contact}            from '../models/contact';
import {ContactService}     from '../services/contact.service';

declare var jQuery: any;

@Component({
    selector: 'contact',
    templateUrl: 'app/views/contact.html',
    providers: [ContactService]
})

export class ContactComponent {
    model = new Contact();
    responseStatus;
    responseMessage = "";

    constructor(private _contact_service: ContactService) {
    }

    ngOnInit() {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-contact").addClass("active");
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#contactButton").button('loading');

        this._contact_service.send(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#contactButton").button('reset');

                this.responseStatus = response.status != 'error';
                this.responseMessage = response.message;
                //noinspection TypeScriptUnresolvedFunction
                jQuery("#contactForm").trigger('reset');
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#contactButton").button('reset');
            }
        )
    }
}