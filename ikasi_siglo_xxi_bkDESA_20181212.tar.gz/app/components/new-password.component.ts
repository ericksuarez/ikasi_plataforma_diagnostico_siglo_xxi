import {Component, OnInit} from "@angular/core";
import {ActivatedRoute} from "@angular/router";
import {RegisterService} from "../services/register.service";
import {PasswordReset} from "../models/password-reset";
import {NotificationsService} from "angular2-notifications";

declare let jQuery: any;

@Component({
    selector: 'new-password',
    templateUrl: 'app/views/new_password.html',
    providers: [RegisterService, NotificationsService]
})

export class NewPasswordComponent implements OnInit {
    public dontMatch = false;

    public model = new PasswordReset();

    public seconds = 10;

    public success = false;

    public options = {
        timeOut: 5000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['right', 'bottom']
    };

    constructor(private _activateRoute: ActivatedRoute,
                private _registerService: RegisterService,
                private _notificationsService: NotificationsService) {
    }

    ngOnInit(): void {
        this._activateRoute.params.subscribe(params => {
            this.model.id = params['id'];
            this.model.token = params['token'];
        });
    }

    onSubmit(): void {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#recoveryButton").button('loading');
        this.dontMatch = false;
        if (!this.passwordMatch()) {
            this.dontMatch = true;
            return;
        }

        this._registerService.changePasswordWithtoken(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#recoveryButton").button('reset');
                if (response.status == 'error') {
                    this._notificationsService.error(response.title, response.message);
                    return;
                }

                this.success = true;
                let self = this;
                let countdown = setInterval(() => {
                    self.seconds = self.seconds - 1;
                    if (self.seconds == 0) {
                        clearInterval(countdown);
                        // Redirect
                        location.href = '/login';
                    }
                }, 1000);

            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#recoveryButton").button('reset');
            }
        );
    }

    passwordMatch(): boolean {
        return this.model.password == this.model.password_repeat;
    }
}