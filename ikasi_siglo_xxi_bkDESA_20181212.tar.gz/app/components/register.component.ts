import {Component} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router'
import {Register} from "../models/register";
import {SpecialtyService} from '../services/specialty.service';
import {EducationLevelService} from '../services/education-level.service';
import {TeacherFunctionService} from '../services/teacher-function.service';
import {RegisterService} from '../services/register.service';
import {AuthService} from "../services/auth.service";
import {Helper} from "../helpers/helper";

declare var jQuery: any;

@Component({
    selector: 'register',
    templateUrl: 'app/views/register.html',
    providers: [AuthService, SpecialtyService, EducationLevelService, TeacherFunctionService, RegisterService, Helper]
})

export class RegisterComponent {
    public model = new Register();
    public specialty_list;
    public education_level_list;
    public teacher_function_list;
    public errorMessage;
    public error = false;
    public pre_register;

    constructor(private _authService: AuthService,
                private _activatedRoute: ActivatedRoute,
                private _router: Router,
                private _specialtyService: SpecialtyService,
                private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _registerService: RegisterService,
                private _helper: Helper) {
    }

    ngOnInit() {
        if (this._authService.isLoggedIn()) {
            //noinspection JSIgnoredPromiseFromCall
            this._router.navigate(["/"]);
        }

        this._specialtyService.getList().subscribe(
            response => {
                this.specialty_list = response;
            }, error => {
                console.log("Error al cargar las especialidades");
            }
        );

        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );

        this._activatedRoute.params.subscribe(
            params => {
                let data = params['data'];
                if(typeof data != "undefined") {
                    this.pre_register = JSON.parse(this._helper.base64Decode(data));
                    this.model.curp = this.pre_register.curp;
                    this.model.fullname = this.pre_register.name;
                    this.model.email = this.pre_register.email;
                    this.model.specialty = this.pre_register.speciality;
                    this.model.education_level = this.pre_register.educationLevel;
                    this.model.teacher_function = this.pre_register.teacherFunction;
                }
            }
        )
    }

    onSubmit() {
        this.error = false;
        //noinspection TypeScriptValidateJSTypes
        jQuery("#registerButton").button('loading');
        this._registerService.register(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#registerButton").button('reset');
                if (response.status == 'error') {
                    this.errorMessage = response.message;
                    this.error = true;
                    return;
                }
                // Si no existe un error, direccionamos a la página de confirmación
                this._router.navigate(["confirmation"]);
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#registerButton").button('reset');
                this.errorMessage = <any>error;
                if (this.errorMessage != null) {
                    console.log(this.errorMessage);
                }
            }
        )
    }
}