import {Component} from "@angular/core";
import {UserService} from "../services/user.service";
import {Helper} from "../helpers/helper";
import {Router} from "@angular/router";

declare var jQuery: any;

@Component({
    selector: 'check',
    templateUrl: 'app/views/check.html',
    providers: [UserService, Helper]
})

export class CheckComponent {
    public model = {
        curp: null
    };

    private showError = false;
    public message;
    private exists = false;

    constructor(private _userService: UserService,
                private _helper: Helper,
                private _router: Router,) {
    }

    onSubmit(): void {
        this.showError = false;
        this.exists = false;
        //noinspection TypeScriptValidateJSTypes
        jQuery("#recoveryButton").button('loading');
        this._userService.checkCurp(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#recoveryButton").button('reset');
                if (response.status == 'error') {
                    if (response.code == 1001) {
                        this.exists = true;
                    }
                    this.showError = true;
                    this.message = response.message;
                } else {
                    this._router.navigate(["register", this._helper.base64Encode(JSON.stringify(response.data))]);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#recoveryButton").button('reset');
            }
        )
    }
}