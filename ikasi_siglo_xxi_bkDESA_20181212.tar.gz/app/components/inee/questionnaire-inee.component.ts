import {Component, OnInit} from "@angular/core";
import {EvaluationIneeService} from "../../services/evaluation-inee.service";
import {ActivatedRoute, Router} from "@angular/router";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
declare let jQuery: any;

@Component({
    selector: 'questionnaire-inee',
    templateUrl: 'app/views/inee/questionnaire.html',
    providers: [EvaluationIneeService, NotificationsService]
})

export class QuestionnaireIneeComponent implements OnInit {
    public loading;
    public questions = [];
    public form = {
        dimension: null,
        answers: {},
        total: null
    };

    public options = {
        timeOut: 5000,
        lastOnBottom: true,
        clickToClose: false,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: false,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['right', 'bottom']
    };

    constructor(private evaluationIneeService: EvaluationIneeService, private _activatedRoute: ActivatedRoute,
                private _notificationsService: NotificationsService, private _router: Router,) {
    }

    ngOnInit(): void {
        this.loading = true;
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-century-xxi-evaluation").addClass("active");
        this._activatedRoute.params.subscribe(params => {
            this.form.dimension = params['dimension'];
            this.evaluationIneeService.getQuestionnaire(params['dimension'], params['educationLevel'], params['teacherFunction']).subscribe(
                response => {
                    this.loading = false;
                    this.questions = response;
                    this.form.total = this.questions.length;
                }, error => {
                    console.log(error);
                }
            )
        });
    }

    onSubmit(): void {
        jQuery("#questionnaireFormButton").button('loading');
        this.evaluationIneeService.save(this.form).subscribe(
            response => {
                jQuery("#questionnaireFormButton").button('reset');
                if (response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                    setTimeout(() => {
                        this._router.navigate(["/evaluation-inee/index"]);
                    }, 5000);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                jQuery("#questionnaireFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un problema con el servidor");
            }
        )
    }
}