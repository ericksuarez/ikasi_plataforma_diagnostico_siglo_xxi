import {Component, OnInit} from "@angular/core";
import {EvaluationIneeService} from "../../services/evaluation-inee.service";
declare let jQuery: any;

@Component({
    selector: 'evaluation-inne',
    templateUrl: 'app/views/inee/evaluation-teacher.html',
    providers: [EvaluationIneeService]
})

export class EvaluationTeacherComponent implements OnInit {
    public dimensions;
    public loading = false;
    public showGraphic = false;
    public radarChartLabels:string[];
    public radarChartData:any;
    public radarChartType:string = 'radar';

    constructor(private evaluationIneeService: EvaluationIneeService) {
    }

    ngOnInit(): void {
        this.loading = true;
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-century-xxi-evaluation").addClass("active");
        this.evaluationIneeService.getDimentionToEvaluate().subscribe(
            response => {
                if(response.data) {
                    this.radarChartLabels = response.dimensions;
                    this.radarChartData = response.data;
                    this.loading = false;
                    this.showGraphic = true;
                    this.saveImage();
                } else {
                    this.dimensions = response;
                    this.loading = false;
                }
            }, error => {
                this.loading = false;
                console.log(error);
            }
        )
    }

    /**
     * Get image from canvas and save in data teacher
     */
    saveImage():void {
        setTimeout(() => {
            let canvas : any = document.getElementById("graphInee");
            let image = canvas.toDataURL("image/png");
            this.evaluationIneeService.saveImage(image).subscribe(
                response => {
                }, error => {
                    console.log(error);
                }
            )
        }, 1000);
    }
}