import {Component, OnInit, Inject} from "@angular/core";
import {CourseService} from "../services/course.service";
import {APP_CONFIG, IAppConfig} from "../app.config";

declare var jQuery: any;

@Component({
    selector: 'suggested-course',
    templateUrl: 'app/views/suggested-course.html',
    providers: [CourseService]
})

export class SuggestedCourseComponent implements OnInit {
    public loading;
    public courses = [];
    public urlResource;

    constructor(private _courseService: CourseService,
                @Inject(APP_CONFIG) private config: IAppConfig) {
        this.urlResource = config.apiEndPointUploads;
    }

    ngOnInit(): void {
        this.loading = true;
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-suggested-courses").addClass("active");
        this._courseService.suggestions().subscribe(
            response => {
                this.courses = response;
                this.loading = false;
            }, error => {
                this.loading = false;
                console.log("Error al cargar cursos");
            }
        )
    }
}