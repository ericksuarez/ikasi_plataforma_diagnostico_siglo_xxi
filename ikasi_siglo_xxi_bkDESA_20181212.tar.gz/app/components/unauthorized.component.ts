import {Component} from '@angular/core';
@Component({
    selector: 'not-found',
    templateUrl: 'app/views/401.html',
})
export class UnauthorizedComponent { }