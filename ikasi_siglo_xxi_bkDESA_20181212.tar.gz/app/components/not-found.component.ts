import {Component} from '@angular/core';
@Component({
    selector: 'not-found',
    templateUrl: 'app/views/404.html',
})
export class NotFoundComponent { }