import {Component}          from '@angular/core';
import {ActivatedRoute}     from '@angular/router'
import {RegisterService}    from '../services/register.service';

@Component({
    selector: 'activate',
    templateUrl: 'app/views/activate.html',
    providers: [RegisterService]
})

export class ActivateComponent {
    private id;
    private authKey;
    title_breadcrumb;
    error = false;

    constructor(private _activateRoute: ActivatedRoute,
                private _registerService: RegisterService) {
    }

    ngOnInit() {
        this._activateRoute.params.subscribe(params => {
            this.id = params['id'];
            this.authKey = params['authKey'];
        });

        this._registerService.activate(this.id, this.authKey).subscribe(
            response => {
                if(response.status == 'error') {
                    this.error = true;
                }

                this.title_breadcrumb = response.message;
            }, error => {
                this.error = true;
                this.title_breadcrumb = "Error al activar la cuenta";
            }
        )
    }
}