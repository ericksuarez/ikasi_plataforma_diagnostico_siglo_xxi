import {Component} from '@angular/core';
@Component({
    selector: 'confirmation',
    templateUrl: 'app/views/confirmation.html'
})
export class ConfirmationComponent { }