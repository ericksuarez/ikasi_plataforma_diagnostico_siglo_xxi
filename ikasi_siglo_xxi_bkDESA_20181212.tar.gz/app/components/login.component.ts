import {Component} from '@angular/core';
import {Login} from "../models/login";
import {AuthService} from "../services/auth.service";
import {Router} from "@angular/router";

declare let jQuery: any;

@Component({
    selector: 'login',
    templateUrl: 'app/views/login.html',
    providers: [AuthService]
})
export class LoginComponent {
    model = new Login();
    errorMessage;
    error = false;

    constructor(private _authService: AuthService, private _router: Router) {
    }

    ngOnInit() {
        if (this._authService.isLoggedIn()) {
            this._router.navigate(["/"]);
        }
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#submitLogin").button('loading');
        this.error = false;
        this._authService.login(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#submitLogin").button('reset');
                if (response.status == 'error') {
                    this.errorMessage = response.message;
                    this.error = true;
                    return;
                }

                this._authService.getIdentity(response.token).subscribe(response => {
                    if (response.hasOwnProperty('sub')) {
                        localStorage.setItem('profile', JSON.stringify(response));
                        if(this._authService.isAdmin()) {
                            location.href = "/admin/dashboard";
                        } else {
                            location.href = "/index";
                        }
                    }
                });
            },
            error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#submitLogin").button('reset');
                this.errorMessage = <any>error;
                if (this.errorMessage != null) {
                    console.log(this.errorMessage);
                }
            }
        );
    }
}