import {Component} from '@angular/core';
import {AuthService} from "../services/auth.service";
import {Router} from "@angular/router";

declare let jQuery: any;

@Component({
    selector: 'default',
    templateUrl: 'app/views/default.html',
    providers: [AuthService]
})

export class DefaultComponent{
    public noAdmin;

    constructor(private _authService: AuthService, private router: Router) {
        if(this._authService.isAdmin()) {
            this.router.navigate(['/admin/dashboard']);
        } else {
            this.noAdmin = true;
        }
    }

    ngOnInit() {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
    }
}