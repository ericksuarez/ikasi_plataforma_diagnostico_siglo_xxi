import {Component} from '@angular/core';
import {AuthService} from "../services/auth.service";

@Component({
    selector: 'logout',
    templateUrl: 'app/views/logout.html',
    providers: [AuthService]
})
export class LogoutComponent {
    constructor(private _authService: AuthService) {}

    ngOnInit() {
        this._authService.logout();
        location.href = "/login";
    }
}