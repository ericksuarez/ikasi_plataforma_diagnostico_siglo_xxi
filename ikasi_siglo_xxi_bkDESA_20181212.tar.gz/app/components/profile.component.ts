import {Component, OnInit}      from "@angular/core";
import {UserService}            from "../services/user.service";
import {Password}               from "../models/password";
import {Email}                  from "../models/email";
import {AuthService}            from "../services/auth.service";
import {NotificationsService}   from "angular2-notifications";
import {Register}               from "../models/register";
import {TeacherFunctionService} from "../services/teacher-function.service";
import {EducationLevelService}  from "../services/education-level.service";
import {SpecialtyService}       from "../services/specialty.service";

declare var jQuery: any;

@Component({
    selector: 'profile',
    templateUrl: 'app/views/profile.html',
    providers: [UserService, SpecialtyService, EducationLevelService, TeacherFunctionService, NotificationsService]
})

export class ProfileComponent implements OnInit {
    public modelPassword = new Password();
    public modelEmail = new Email();
    public modelPersonal = new Register();
    public dontMatchPassword = false;
    public dontMatchEmail = false;
    public specialty_list;
    public education_level_list;
    public teacher_function_list;
    public options = {
        timeOut: 5000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['right', 'bottom']
    };

    private profile;

    constructor(private _notificationsService: NotificationsService,
                private _userService: UserService,
                private _authService: AuthService,
                private _specialtyService: SpecialtyService,
                private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService) {
        this.profile = _authService.getProfile();
    }

    ngOnInit(): void {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        this._specialtyService.getList().subscribe(
            response => {
                this.specialty_list = response;
            }, error => {
                console.log("Error al cargar las especialidades");
            }
        );

        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );

        this.modelPersonal.fullname = this.profile.fullname;
        this.modelPersonal.curp = this.profile.curp;
        this.modelPersonal.teacher_function = this.profile.teacher_function_id;
        this.modelPersonal.specialty = this.profile.speciality_id;
        this.modelPersonal.education_level = this.profile.educational_level_id;
    }

    /**
     * Cambio de contraseña
     */
    submitPassword(): void {
        this.dontMatchPassword = false;
        if (!ProfileComponent.matchFields(this.modelPassword.newPassword, this.modelPassword.repeatNewPassword)) {
            this.dontMatchPassword = true;
            return;
        }

        //noinspection TypeScriptValidateJSTypes
        jQuery("#passwordButton").button('loading');

        this._userService.changePassword(this.modelPassword).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#passwordButton").button('reset');
                if (response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#passwordButton").button('reset');
                this._notificationsService.error("Error", "Imposible cambiar la contraseña");
            }
        );
    }

    /**
     * Cambio de correo electrónico
     */
    submitEmail(): void {
        this.dontMatchEmail = false;
        if (!ProfileComponent.matchFields(this.modelEmail.email, this.modelEmail.emailRepeat)) {
            this.dontMatchEmail = true;
            return;
        }

        //noinspection TypeScriptValidateJSTypes
        jQuery("#emailButton").button('loading');

        this._userService.changeEmail(this.modelEmail).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#emailButton").button('reset');
                if (response.status == 'success') {
                    this._authService.updateProfile(response.token);
                    this.profile.email = this.modelEmail.email;
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#emailButton").button('reset');
                this._notificationsService.error("Error", "Imposible cambiar el correo electrónico");
            }
        );
    }

    submitProfile(): void {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#profileButton").button('loading');

        this._userService.updateProfile(this.modelPersonal).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#profileButton").button('reset');
                if (response.status == 'success') {
                    this._authService.updateProfile(response.token);
                    this._notificationsService.success(response.title, response.message);

                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#emailButton").button('reset');
                this._notificationsService.error("Error", "Imposible cambiar el correo electrónico");
            }
        )
    }

    /**
     * Compara dos campos para verificar que sean iguales
     * @param original
     * @param compare
     * @returns {boolean}
     */
    static matchFields(original, compare): boolean {
        return original == compare;
    }
}