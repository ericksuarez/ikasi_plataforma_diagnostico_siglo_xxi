import {Component, OnInit} from "@angular/core";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute, Router} from "@angular/router";
import {AuthService} from "../../services/auth.service";
import {SkillCenturyQuestionCenturyService} from "../../services/skill-century-question-century.service";
import {SkillCenturyTeacherAnswerCenturyService} from "../../services/skill-century-teacher-answer-century.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/apply-evaluation/evaluating.html',
    providers: [SkillCenturyQuestionCenturyService, AuthService, SkillCenturyTeacherAnswerCenturyService, NotificationsService]
})
export class ApplyCenturyEvaluating implements OnInit {
    public categories;
    public areas;
    public loading = false;
    public areaId;
    public answers = [];
    public jsonAnswers;
    private json;
    public area;

    constructor(public _skillCenturyQuestionCenturyService: SkillCenturyQuestionCenturyService,
                public _skillCenturyTeacherAnswerCenturyService: SkillCenturyTeacherAnswerCenturyService,
                private _authService: AuthService,
                private activatedRoute: ActivatedRoute,
                private _notificationsService: NotificationsService,
                private _router: Router) {
    }

    ngOnInit() {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-century-xxi-evaluation").addClass("active");
        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.area = params['name'];
        });
        this.activatedRoute.params.subscribe(params => {
            this.areaId = params['id'];
            this._skillCenturyQuestionCenturyService.findByArea(this.areaId, this._authService.getProfile().sub).subscribe(
                response => {
                    this.categories = response.data;
                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });
    }

    addValue(questionId, answerId) {
        this.answers["q_" + questionId] = answerId;
        this.json = "[";
        for (let i in this.answers) {
            this.json += '{"' + i + '": ' + this.answers[i] + '},';
        }
        this.json += "]";
    }

    saveAnswers() {
        //noinspection TypeScriptValidateJSTypes
        jQuery(".saveButton").val("Guardando...")

        document.getElementsByClassName("guar")
        this._skillCenturyTeacherAnswerCenturyService.saveAnswer(this.json, this._authService.getProfile().sub).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#skillFormButton").button('reset');
                if (response.status == 'success') {
                    this._router.navigate(["/evaluation-xxi/index"]);
                    //alert("Guardado correctamente");
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        );
    }
}