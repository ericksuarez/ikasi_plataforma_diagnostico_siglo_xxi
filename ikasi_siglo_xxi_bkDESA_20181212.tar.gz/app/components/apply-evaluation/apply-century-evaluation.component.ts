import {Component, OnInit} from "@angular/core";
import {SkillCenturyService} from "../../services/skill-century.service";
import {SkillCenturyAreaService} from "../../services/skill-century-area.service";
import {SkillCenturyTeacherAnswerCenturyService} from "../../services/skill-century-teacher-answer-century.service";
import {DataResultEvaluationXII} from "../../models/DataResultEvaluationXII";
import {AuthService} from "../../services/auth.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/apply-evaluation/index.html',
    providers: [SkillCenturyService, SkillCenturyAreaService, SkillCenturyTeacherAnswerCenturyService],
    selector: 'radar-chart-demo',
})


export class ApplyCenturyEvaluation implements OnInit {
    public skills;
    public areas = [];
    public loading = false;
    public totalQuestions:number = 0;
    public totalAnswered:number = 0;
    public percentage:number = 0;
    public results;
    public showGraph = false;
    public color=[{"Vulnerable":"alert","Competente":"waring","Optimo":"success"}];
    public graphImage : any = "";
    public userId;
    public directoryUploadsEvaluationXXI = "evaluation_xxi_teacher_";

    // Radar
    public radarChartLabels:string[] = [];

    public radarChartData:any = [];

    public radarChartType:string = 'radar';

    constructor(public _skillCenturyService: SkillCenturyService,
                public _skillCenturyAreaService: SkillCenturyAreaService,
                public _skillCenturyTeacherAnswerCenturyService : SkillCenturyTeacherAnswerCenturyService,
                private _authService : AuthService
    ){}

    ngOnInit() {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-century-xxi-evaluation").addClass("active");
        this.loading = true;
        this.userId = this._authService.getProfile().teacher_id;

        this._skillCenturyService.findAll(-1).subscribe(
            response => {
                this.skills = response.data;

                if (this.skills.length == 0) {
                    this.loading = false;
                }

                for (let i = 0; i < this.skills.length; i++) {
                    this._skillCenturyAreaService.findAll(this.skills[i].id, -1).subscribe(
                        response => {
                            this.areas[this.skills[i].id] = response.data;
                            let areas = this.areas[this.skills[i].id];
                            for(let area of areas) {
                                this.totalQuestions += area.totalQuestions;
                                this.totalAnswered += area.questionsAnswered;
                            }

                            this.percentage = parseInt((this.totalAnswered/this.totalQuestions) * 100 + "");
                            document.getElementById('barra').style.width = this.percentage + "%";
                            this.loading = false;
                        }, error => {
                            this.loading = false;
                            console.log(error);
                        }
                    );
                }

                this._skillCenturyTeacherAnswerCenturyService
                    .getResults().subscribe(
                    response => {
                        this.showGraph = false;
                        if(response.didFinish != null){
                            this.showGraph = true;
                        }

                        this.results = response.data;
                        let data;
                        let cuantosMas = 0;
                        for(let result of this.results){
                            data = new DataResultEvaluationXII();
                            data.label = result.name;
                            for(let i=0;i < cuantosMas;i++){
                                data.data.push(0);
                            }
                            for(let area of result.areas){
                                this.radarChartLabels.push(area.name);
                                data.data.push(area.result);
                                cuantosMas++;
                            }
                            this.radarChartData.push(data);
                        }

                        //this.showGraph = true;
                        let cen = new ApplyCenturyEvaluation(this._skillCenturyService, this._skillCenturyAreaService, this._skillCenturyTeacherAnswerCenturyService, this._authService);
                        cen.userId = this.userId;
                        setTimeout(function(){
                            cen.getImage(cen);
                        },1000);

                    }, error => {
                        this.loading = false;
                        console.log(error);
                    }
                );
            }, error => {
                console.log(error);
            }
        );
    }

    exportResult(){
        this._skillCenturyTeacherAnswerCenturyService
            .exportResultToPDF()
            .subscribe(
                response=>{
                    if(response.status == 'success'){
                        window.open(this._skillCenturyTeacherAnswerCenturyService.apiEndPoint + this.directoryUploadsEvaluationXXI
                            + response.userId + "/result.pdf",'_blank');
                    }
                },error=>{

                }
            );
    }

    getImage(cen){
        cen.userId = this.userId;
        this.loading = true;
        let canvas : any = document.getElementById("resultGraph");
        if(canvas) {
            // let context: any = canvas.getContext('2d');
            cen.graphImage = this.graphImage = canvas.toDataURL("image/png");
            cen._skillCenturyTeacherAnswerCenturyService
                .saveImage(cen.graphImage, cen.userId)
                .subscribe(response => {
                    if (response.status == "error") {
                        console.log("Error al guardar la imagen");
                    } else {
                        console.log("Imagen guardada correctamente");
                    }
                }, error => {
                    console.log(error);
                });
        }
    }
}