import {Component} from "@angular/core";
import {RegisterService} from "../services/register.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";

declare var jQuery: any;

@Component({
    selector: 'password-recovery',
    templateUrl: 'app/views/password-recovery.html',
    providers: [RegisterService, NotificationsService]
})

export class PasswordRecoveryComponent {
    public model = {
        email: null
    };

    public options = {
        timeOut: 10000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['right', 'bottom']
    };

    constructor(private _registerService: RegisterService,
                private _notificationsService: NotificationsService) {

    }

    onSubmit(): void {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#recoveryButton").button('loading');
        this._registerService.passwordRecovery(this.model.email).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#recoveryButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#recoveryButton").button('reset');
            }
        )
    }
}