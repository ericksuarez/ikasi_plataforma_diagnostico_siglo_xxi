import {Component} from "@angular/core";
import {EducationLevelService} from "../../../services/education-level.service";
import {TeacherFunctionService} from "../../../services/teacher-function.service";
import {IneeService} from "../../../services/inee.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {IneeEvaluation} from "../../../models/inee-evaluation";
import {ActivatedRoute} from "@angular/router";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/inee/evaluation/update.html',
    providers: [EducationLevelService, TeacherFunctionService, IneeService, NotificationsService]
})

export class AdminIneeEvaluationUpdateComponent {
    public model = new IneeEvaluation();
    private selector;
    private selectorArg;
    public education_level_list = [];
    public teacher_function_list = [];
    public dimension_list = [];
    public parameter_list = [];
    public indicator_list = [];
    public questionsCollection: any = [];
    public questionId;

    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _ineeService: IneeService,
                private _notificationsService: NotificationsService,
                private _activatedRoute: ActivatedRoute,) {
    }

    ngOnInit(): void {
        this.selector = jQuery("#validator-dimension-ckeditor");
        this.selectorArg = jQuery("#validator-argumentation-ckeditor");
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-inee").addClass("active");
        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );

        this._activatedRoute.params.subscribe(params => {
            this.questionId = params['id'];
            this._ineeService.viewQuestion(this.questionId).subscribe(
                response => {
                    this.model = response;
                    this.showDimensions(response.teacher_function);
                    this.showParameters(response.dimension);
                    this.showIndicators(response.parameter);
                    this.model.answerCollection = response.answers;
                }
            )

        });
    }

    onSubmit(): void {
        if(!this.model.correctAnswer) {
            return;
        }
        jQuery("#questionFormButton").button('loading');
        this._ineeService.updateQuestion(this.model, this.questionId).subscribe(
            response => {
                jQuery("#questionFormButton").button('reset');
                if (response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                jQuery("#questionFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un error al guardar los datos");
            }
        )
    }

    /**
     * Fill select dimensions
     * @param teacher_function
     */
    showDimensions(teacher_function): void {
        this.dimension_list = [];
        this.parameter_list = [];
        this.indicator_list = [];
        this._ineeService.getList(this.model.education_level, teacher_function).subscribe(
            response => {
                this.dimension_list = response;
            }
        );
    }

    /**
     * Fill select parameters
     * @param dimensionId
     */
    showParameters(dimensionId): void {
        this.parameter_list = [];
        this._ineeService.getListParameter(dimensionId).subscribe(
            response => {
                this.parameter_list = response;
            }
        );
    }

    /**
     * Fill select indicators
     * @param parameterId
     */
    showIndicators(parameterId): void {
        this.indicator_list = [];
        this._ineeService.getListIndicator(parameterId).subscribe(
            response => {
                this.indicator_list = response;
            }
        )
    }

    /**
     * Add answer to collection
     */
    addAnswer() {
        this.model.answerCollection.push({id: null, title: this.model.answer});
        this.model.answer = null;
    }

    /**
     * Delete answer from collection
     * @param name
     */
    deleteAnswer(name) {
        let index = this.model.answerCollection.indexOf(name);
        this.model.answerCollection[index]['removed'] = true;
        if(!this.model.answerCollection[index]['id']) {
            this.model.answerCollection.splice(index, 1);
        }
    }

    onChange(event) {
        if (event.length > 0) {
            this.selector.removeClass('custom-ckeditor-invalid');
            this.selector.addClass('custom-ckeditor-valid');
        } else {
            this.selector.removeClass('custom-ckeditor-valid');
            this.selector.addClass('custom-ckeditor-invalid');
        }
    }

    onChangeArg(event) {
        if (event.length > 0) {
            this.selectorArg.removeClass('custom-ckeditor-invalid');
            this.selectorArg.addClass('custom-ckeditor-valid');
        } else {
            this.selectorArg.removeClass('custom-ckeditor-valid');
            this.selectorArg.addClass('custom-ckeditor-invalid');
        }
    }
}