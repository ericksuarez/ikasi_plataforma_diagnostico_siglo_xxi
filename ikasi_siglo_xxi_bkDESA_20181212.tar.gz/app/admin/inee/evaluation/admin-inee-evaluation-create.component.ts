import {Component, OnInit} from "@angular/core";
import {IneeService} from "../../../services/inee.service";
import {TeacherFunctionService} from "../../../services/teacher-function.service";
import {EducationLevelService} from "../../../services/education-level.service";
import {IneeEvaluation} from "../../../models/inee-evaluation";
import {NotificationsService} from "angular2-notifications";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/inee/evaluation/create.html',
    providers: [EducationLevelService, TeacherFunctionService, IneeService, NotificationsService]
})

export class AdminIneeEvaluationCreateComponent implements OnInit {
    public model = new IneeEvaluation();
    public education_level_list = [];
    public teacher_function_list = [];
    public dimension_list = [];
    public parameter_list = [];
    public indicator_list = [];
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
    public questionsCollection: any = [];
    private selector;
    private selectorArg;

    constructor(private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _ineeService: IneeService,
                private _notificationsService: NotificationsService) {
        this.model.answerCollection = [];
    }

    ngOnInit(): void {
        this.selector = jQuery("#validator-dimension-ckeditor");
        this.selectorArg = jQuery("#validator-argumentation-ckeditor");
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-inee").addClass("active");
        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );
    }

    /**
     * Reset form values per default
     */
    resetForm(): void {
        this.dimension_list = [];
        this.parameter_list = [];
        this.indicator_list = [];
        this.model.teacher_function = "";
        this.model.dimension = "";
        this.model.parameter = "";
    }

    /**
     * Fill select dimensions
     * @param teacher_function
     */
    showDimensions(teacher_function): void {
        this.dimension_list = [];
        this.parameter_list = [];
        this.indicator_list = [];
        this._ineeService.getList(this.model.education_level, teacher_function).subscribe(
            response => {
                this.dimension_list = response;
            }
        );
    }

    /**
     * Fill select parameters
     * @param dimensionId
     */
    showParameters(dimensionId): void {
        this.parameter_list = [];
        this._ineeService.getListParameter(dimensionId).subscribe(
            response => {
                this.parameter_list = response;
            }
        );
    }

    /**
     * Fill select indicators
     * @param parameterId
     */
    showIndicators(parameterId): void {
        this.indicator_list = [];
        this._ineeService.getListIndicator(parameterId).subscribe(
            response => {
                this.indicator_list = response;
            }
        )
    }

    /**
     * Add answer from collection
     */
    addAnswer() {
        this.model.answerCollection.push(this.model.answer);
        this.model.answer = null;
    }

    /**
     * Delete answer from collection
     * @param name
     */
    deleteAnswer(name) {
        let index = this.model.answerCollection.indexOf(name);
        this.model.answerCollection.splice(index, 1);
    }

    onSubmit(): void {
        if(!this.model.correctAnswer) {
            return;
        }
        jQuery("#questionFormButton").button('loading');
        this._ineeService.createQuestion(this.model).subscribe(
            response => {
                jQuery("#questionFormButton").button('reset');
                if (response.status == 'success') {
                    this.questionsCollection.push(response.data);
                    this.model.reagent_base = null;
                    this.model.argumentation = null;
                    this.model.answerCollection = [];
                    this.model.correctAnswer = null;
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                jQuery("#questionFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un error al guardar los datos");
            }
        )
    }

    onChange(event) {
        if (event.length > 0) {
            this.selector.removeClass('custom-ckeditor-invalid');
            this.selector.addClass('custom-ckeditor-valid');
        } else {
            this.selector.removeClass('custom-ckeditor-valid');
            this.selector.addClass('custom-ckeditor-invalid');
        }
    }

    onChangeArg(event) {
        if (event.length > 0) {
            this.selectorArg.removeClass('custom-ckeditor-invalid');
            this.selectorArg.addClass('custom-ckeditor-valid');
        } else {
            this.selectorArg.removeClass('custom-ckeditor-valid');
            this.selectorArg.addClass('custom-ckeditor-invalid');
        }
    }
}