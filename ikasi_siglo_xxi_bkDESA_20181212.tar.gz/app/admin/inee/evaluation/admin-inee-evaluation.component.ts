import {Component, OnInit} from "@angular/core";
import {EducationLevelService} from "../../../services/education-level.service";
import {TeacherFunctionService} from "../../../services/teacher-function.service";
import {IneeService} from "../../../services/inee.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/inee/evaluation/index.html',
    providers: [EducationLevelService, TeacherFunctionService, IneeService, NotificationsService]
})

export class AdminIneeEvaluationComponent implements OnInit {
    public questions: any = [];
    public model = {
        education_level: null,
        teacher_function: null
    };
    public education_level_list = [];
    public teacher_function_list = [];
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _ineeService: IneeService,
                private _notificationsService: NotificationsService) {
    }

    ngOnInit(): void {
        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#evaluationButton").button('loading');
        this._ineeService.filterEvaluation(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#evaluationButton").button('reset');
                this.questions = response;
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#evaluationButton").button('reset');
            }
        )
    }

    deleteQ(id) {
        let response;
        response = confirm('¿Desea eliminar el reactivo?');

        if(response) {
            this._ineeService.deleteQuestion(id).subscribe(
                response => {
                    if(response.status == 'success') {
                        this._notificationsService.success(response.title, response.message);
                        jQuery("#question-" + id).remove();
                    } else {
                        this._notificationsService.error(response.title, response.message);
                    }
                }, error => {
                    this._notificationsService.error(response.title, response.message);
                }
            )
        }
    }
}