import {Component} from "@angular/core";
import {SpecialtyService} from "../../services/specialty.service";
import {CatalogForm} from "../../models/catalog_form";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/speciality/create.html',
    providers: [SpecialtyService, NotificationsService]
})

export class AdminSpecialityCreateComponent {

    public model = new CatalogForm();
    public specialities = [];
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(private specialtyService: SpecialtyService, private _notificationsService: NotificationsService) {
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#specialityFormButton").button('loading');
        this.specialtyService.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#specialityFormButton").button('reset');
                if(response.status == 'success') {
                    this.specialities.push(response);
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        )
    }
}