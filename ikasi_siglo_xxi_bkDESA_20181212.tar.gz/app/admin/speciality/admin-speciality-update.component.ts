import {Component, OnInit} from "@angular/core";
import {CatalogForm} from "../../models/catalog_form";
import {Helper} from "../../helpers/helper";
import {ActivatedRoute} from "@angular/router";
import {SpecialtyService} from "../../services/specialty.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/speciality/update.html',
    providers: [Helper, SpecialtyService, NotificationsService]
})

export class AdminSpecialityUpdateComponent extends Helper implements OnInit{

    public model = new CatalogForm();

    public specialityId;

    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(
        private activatedRoute: ActivatedRoute,
        private helper: Helper,
        private specialtyService: SpecialtyService,
        private _notificationsService: NotificationsService
    ) {
        super();
    }

    ngOnInit(): void {
        this.activatedRoute.params.subscribe(
            params => {
                let name = params['name'];
                this.model.name = this.helper.base64Decode(name);
                this.specialityId = params['id'];
            }
        );

    }

    onSubmit() {
        jQuery("#specialityFormButton").button('loading');
        this.specialtyService.update(this.model, this.specialityId).subscribe(
            response => {
                jQuery("#specialityFormButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            },error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#updateTeacherButton").button('reset');
                this._notificationsService.error("Error", "Ocurrio un error al tratar de actualizar la información");
            }
        )
    }

}