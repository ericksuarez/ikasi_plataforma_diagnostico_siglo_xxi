import {Component, OnInit} from "@angular/core";
import {SpecialtyService} from "../../services/specialty.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../helpers/helper";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/speciality/index.html',
    providers: [SpecialtyService]
})

export class AdminSpecialityComponent extends Helper implements OnInit {
    public specialities;
    public loading;
    // Total de páginas
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    // Página actual
    public page;

    constructor(private specialityService: SpecialtyService,
                private activatedRoute: ActivatedRoute) {
        super();
    }

    ngOnInit(): void {
        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.page = params['page'];
            if (!this.page) {
                this.page = 1;
            }
            this.specialityService.findAll(this.page).subscribe(
                response => {
                    this.specialities = response.data;
                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }
                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });

        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-catalog").addClass("active");
    }

}