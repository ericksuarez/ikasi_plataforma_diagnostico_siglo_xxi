import {Component, OnInit} from "@angular/core";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/evaluation/index.html'
})

export class AdminEvaluationComponent implements OnInit{
    ngOnInit(): void {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-evaluation").addClass("active");
    }
}