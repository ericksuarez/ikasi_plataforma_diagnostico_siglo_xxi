import {Component}              from "@angular/core";
import {Password}               from "../../models/password";
import {Email}                  from "../../models/email";
import {NotificationsService}   from "angular2-notifications";
import {UserService}            from "../../services/user.service";
import {AuthService}            from "../../services/auth.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/profile.html',
    providers: [UserService, NotificationsService]
})

export class AdminProfileComponent {
    public modelPassword = new Password();
    public modelEmail = new Email();
    public dontMatchPassword = false;
    public dontMatchEmail = false;
    public options = {
        timeOut: 5000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['right', 'bottom']
    };

    private profile;

    constructor(private _notificationsService: NotificationsService,
                private _userService: UserService,
                private _authService: AuthService) {
        this.profile = _authService.getProfile();
    }

    /**
     * Cambio de contraseña
     */
    submitPassword(): void {
        this.dontMatchPassword = false;
        if (!AdminProfileComponent.matchFields(this.modelPassword.newPassword, this.modelPassword.repeatNewPassword)) {
            this.dontMatchPassword = true;
            return;
        }

        //noinspection TypeScriptValidateJSTypes
        jQuery("#passwordButton").button('loading');

        this._userService.changePassword(this.modelPassword).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#passwordButton").button('reset');
                if (response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#passwordButton").button('reset');
                this._notificationsService.error("Error", "Imposible cambiar la contraseña");
            }
        );
    }

    /**
     * Cambio de correo electrónico
     */
    submitEmail(): void {
        this.dontMatchEmail = false;
        if (!AdminProfileComponent.matchFields(this.modelEmail.email, this.modelEmail.emailRepeat)) {
            this.dontMatchEmail = true;
            return;
        }

        //noinspection TypeScriptValidateJSTypes
        jQuery("#emailButton").button('loading');

        this._userService.changeEmail(this.modelEmail).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#emailButton").button('reset');
                if (response.status == 'success') {
                    this._authService.updateProfile(response.token);
                    this.profile.email = this.modelEmail.email;
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#emailButton").button('reset');
                this._notificationsService.error("Error", "Imposible cambiar el correo electrónico");
            }
        );
    }

    /**
     * Compara dos campos para verificar que sean iguales
     * @param original
     * @param compare
     * @returns {boolean}
     */
    static matchFields(original, compare): boolean {
        return original == compare;
    }
}