import { Component } from '@angular/core';
@Component({
    templateUrl: 'app/views/admin/layout.html'
})
export class AdminComponent {
}
