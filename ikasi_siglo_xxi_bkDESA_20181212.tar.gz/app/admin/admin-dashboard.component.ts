import { Component, OnInit }  from '@angular/core';
import 'rxjs/add/operator/map';

@Component({
    templateUrl:  'app/views/admin/dashboard.html'
})
export class AdminDashboardComponent implements OnInit {
    title;
    ngOnInit() {
        this.title = "Dashboard";
    }
}