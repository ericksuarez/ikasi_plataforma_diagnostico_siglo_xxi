import {Component, OnInit}  from "@angular/core";
import {ActivatedRoute}     from "@angular/router";
import {TeacherService}     from "../../services/teacher.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/teacher/pre-register.html',
    providers: [TeacherService]
})

export class AdminTeacherPreRegisterComponent implements OnInit{
    public loading;
    public teachersList = [];
    // Total de páginas
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    // Página actual
    public page;

    constructor(private teacherService: TeacherService,
                private activatedRoute: ActivatedRoute) {
    }

    ngOnInit(): void {
        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.page = params['page'];
            if (!this.page) {
                this.page = 1;
            }

            this.teacherService.findAllPreRegister(this.page).subscribe(
                response => {
                    this.teachersList = response.data;
                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }
                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
            console.log(this.page);
        });

        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-teacher").addClass("active");
    }
}