import {Component, OnInit} from "@angular/core";
import {User} from "../../models/user";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../helpers/helper";
import {TeacherService} from "../../services/teacher.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/teacher/update.html',
    providers: [Helper, TeacherService, NotificationsService]
})

export class AdminTeacherUpdateComponent extends Helper implements OnInit {
    model;
    oldEmail;
    teacherId;

    options = {
        timeOut: 5000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(
        private activatedRoute: ActivatedRoute,
        private helper: Helper,
        private teacherService: TeacherService,
        private _notificationsService: NotificationsService
    ) {
        super();
    }

    ngOnInit(): void {
        this.activatedRoute.params.subscribe(
            params => {
                let id = params['userId'];
                let email = params['email'];
                let status = params['status'];
                this.teacherId = params['id'];
                this.oldEmail = this.helper.base64Decode(email);
                this.model = new User(id, this.helper.base64Decode(email), status, "");
            }
        )
    }

    onSubmit(): void {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#updateTeacherButton").button('loading');
        this.teacherService.updateUser(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#updateTeacherButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#updateTeacherButton").button('reset');
                this._notificationsService.error("Error", "Ocurrio un error al tratar de actualizar la información");
            }
        )
    }
}