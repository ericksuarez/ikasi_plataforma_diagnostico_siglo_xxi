import {Component, OnInit} from "@angular/core";
import {ActivatedRoute} from "@angular/router";
import {TeacherService} from "../../services/teacher.service";
import {Helper} from "../../helpers/helper";

@Component({
    templateUrl: 'app/views/admin/teacher/profile.html',
    providers: [TeacherService]
})

export class AdminTeacherProfileComponent extends Helper implements OnInit {
    public teacher = {
        user: {},
        speciality: {},
        teacherFunction: {},
        educationLevel: {},
        createTime: {}
    };

    public loading;

    constructor(private activatedRoute: ActivatedRoute,
    private teacherService: TeacherService) {
        super();
    }

    ngOnInit(): void {
        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            let id = params['id'];

            this.teacherService.getProfile(id).subscribe(
                response => {
                    this.teacher = response;
                    this.loading = false;
                }
            )
        })
    }
}