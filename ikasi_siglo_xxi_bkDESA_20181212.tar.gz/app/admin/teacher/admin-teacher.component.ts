import {Component, OnInit} from "@angular/core";
import {TeacherService} from "../../services/teacher.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../helpers/helper";
import {SkillCenturyTeacherAnswerCenturyService} from "../../services/skill-century-teacher-answer-century.service";
import {EvaluationIneeService} from "../../services/evaluation-inee.service";

declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/teacher/index.html',
    providers: [TeacherService, SkillCenturyTeacherAnswerCenturyService, EvaluationIneeService]
})

export class AdminTeacherComponent extends Helper implements OnInit {
    loading;
    teachersList;
    // Total de páginas
    pages;
    // Página anterior
    pagePrev = 1;
    // Siguiente página
    pageNext = 1;
    // Página actual
    page;

    private directoryUploadsEvaluationXXI = "evaluation_xxi_teacher_";


    constructor(private teacherService: TeacherService,
                private _skillCenturyTeacherAnswerCenturyService: SkillCenturyTeacherAnswerCenturyService,
                private activatedRoute: ActivatedRoute,
                private evaluationIneeService: EvaluationIneeService) {
        super();
    }

    ngOnInit(): void {
        //noinspection TypeScriptUnresolvedFunction
        jQuery("body").tooltip({
            selector: '[data-toggle="tooltip"]'
        });

        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.page = params['page'];
            if (!this.page) {
                this.page = 1;
            }

            this.teacherService.findAll(this.page).subscribe(
                response => {
                    this.teachersList = response.data;
                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }
                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });

        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-teacher").addClass("active");
    }

    exportResultData(userId) {
        jQuery("#teacher_" + userId).removeClass("fa-file-excel-o");
        jQuery("#teacher_" + userId).addClass("fa-spin fa-spinner");
        this._skillCenturyTeacherAnswerCenturyService
            .exportResultToExcel(userId)
            .subscribe(
                response => {
                    if (response.status == 'success') {
                        window.open(response.url, '_blank');
                    }
                    jQuery("#teacher_" + userId).removeClass("fa-spin fa-spinner");
                    jQuery("#teacher_" + userId).addClass("fa-file-excel-o");
                }, error => {
                    jQuery("#teacher_" + userId).removeClass("fa-spin fa-spinner");
                    jQuery("#teacher_" + userId).addClass("fa-warning");
                }
            );
    }

    exportResultDataToPDF(userId) {
        jQuery("#teacher_pdf_" + userId).removeClass("fa-file-pdf-o");
        jQuery("#teacher_pdf_" + userId).addClass("fa-spin fa-spinner");
        this._skillCenturyTeacherAnswerCenturyService.teacherId = userId;
        this._skillCenturyTeacherAnswerCenturyService
            .exportResultToPDF()
            .subscribe(
                response => {
                    if (response.status == 'success') {
                        window.open(this._skillCenturyTeacherAnswerCenturyService.apiEndPoint + this.directoryUploadsEvaluationXXI
                            + response.userId + "/result.pdf", '_blank');
                    }
                    jQuery("#teacher_pdf_" + userId).removeClass("fa-spin fa-spinner");
                    jQuery("#teacher_pdf_" + userId).addClass("fa-file-pdf-o");
                }, error => {
                    jQuery("#teacher_pdf_" + userId).removeClass("fa-spin fa-spinner");
                    jQuery("#teacher_pdf_" + userId).addClass("fa-warning");
                }
            );
    }

    /**
     * Export results of evaluation inee to excel
     * @param teacherId
     */
    exportResultIneeDataToExcel(teacherId) {
        let $teacher_excel_inee = jQuery("#teacher_inee_" + teacherId);
        $teacher_excel_inee.removeClass("fa-file-excel-o");
        $teacher_excel_inee.addClass("fa-spin fa-spinner");

        this.evaluationIneeService.exportToExcel(teacherId).subscribe(
            response => {
                if (response.status == 'success') {
                    window.open(response.url, '_blank');
                }
                $teacher_excel_inee.removeClass("fa-spin fa-spinner");
                $teacher_excel_inee.addClass("fa-file-excel-o");
            }, error => {
                $teacher_excel_inee.removeClass("fa-spin fa-spinner");
                $teacher_excel_inee.addClass("fa-warning");
            }
        )
    }

    /**
     * Export results of evaluation inee to PDF
     * @param teacherId
     */
    exportResultIneeDataToPDF(teacherId) {
        let $teacher_pdf_inee = jQuery("#teacher_pdf_inee_" + teacherId);
        $teacher_pdf_inee.removeClass("fa-file-pdf-o");
        $teacher_pdf_inee.addClass("fa-spin fa-spinner");

        this.evaluationIneeService.exportToPDF(teacherId).subscribe(
            response => {
                if (response.status == 'success') {
                    window.open(this._skillCenturyTeacherAnswerCenturyService.apiEndPoint + this.directoryUploadsEvaluationXXI
                        + response.userId + "/result_inee.pdf", '_blank');
                }
                $teacher_pdf_inee.removeClass("fa-spin fa-spinner");
                $teacher_pdf_inee.addClass("fa-file-pdf-o");
            }, error => {
                $teacher_pdf_inee.removeClass("fa-spin fa-spinner");
                $teacher_pdf_inee.addClass("fa-warning");
            }
        )
    }


}