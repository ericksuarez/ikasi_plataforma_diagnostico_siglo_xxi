import {Component, OnInit, Inject} from "@angular/core";
import {UploadService} from "../../services/upload.service";
import {IAppConfig, APP_CONFIG} from "../../app.config";
import {AuthService} from "../../services/auth.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/teacher/import.html',
    providers: [UploadService]
})

export class AdminTeacherImportComponent implements OnInit {
    public ready = false;
    public filesToUpload: Array<File>;
    private url;
    private controller = "/teacher";
    private token;
    public resultUpload;

    constructor(private _uploadService: UploadService,
                private authService: AuthService,
                @Inject(APP_CONFIG) private config: IAppConfig) {
        this.url = config.apiEndPoint + this.controller;
        this.token = authService.getToken();
    }

    ngOnInit(): void {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-teacher").addClass("active");
    }

    loadFile(event): void {
        let input = event.target;
        if (input.files.length == 0) {
            return;
        }
        this.filesToUpload = <Array<File>>input.files;
        let reader = new FileReader();
        reader.onload = () => {
            let dataURL = reader.result;
            jQuery('.preview').attr('src', dataURL);
        };
        reader.readAsDataURL(input.files[0]);
        this.ready = true;
    }

    upload(): void {
        let _url = this.url + "/import";
        this._uploadService.makeFileRequest(this.token, _url, ['file'], this.filesToUpload).then(
            (result) => {
                this.resultUpload = result;
            }, (error) => {
                console.log(error);
            }
        );
    }
}