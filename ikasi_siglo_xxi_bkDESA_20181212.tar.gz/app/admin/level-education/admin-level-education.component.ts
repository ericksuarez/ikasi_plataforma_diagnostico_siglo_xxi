import {Component, OnInit} from "@angular/core";
import {EducationLevelService} from "../../services/education-level.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../helpers/helper";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/level-education/index.html',
    providers: [EducationLevelService]
})

export class AdminLevelEducationComponent extends Helper implements OnInit {
    loading;
    educationLevelList;
    // Total de páginas
    pages;
    // Página anterior
    pagePrev = 1;
    // Siguiente página
    pageNext = 1;
    // Página actual
    page;

    constructor(private levelEducation: EducationLevelService,
                private activatedRoute: ActivatedRoute) {
        super();
    }

    ngOnInit(): void {
        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            let page = params['page'];
            if (!this.page) {
                this.page = 1;
            }

            this.levelEducation.findAll(page).subscribe(
                response => {
                    this.educationLevelList = response.data;
                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }
                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-catalog").addClass("active");
    }
}