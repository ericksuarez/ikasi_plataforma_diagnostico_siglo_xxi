import {Component, OnInit} from "@angular/core";
import {CatalogForm} from "../../models/catalog_form";
import {Helper} from "../../helpers/helper";
import {ActivatedRoute} from "@angular/router";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {EducationLevelService} from "../../services/education-level.service";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/level-education/update.html',
    providers: [Helper, EducationLevelService, NotificationsService]
})

export class AdminLevelEducationUpdateComponent extends Helper implements OnInit{

    public model = new CatalogForm();

    public educationLevelId;

    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(
        private activatedRoute: ActivatedRoute,
        private helper: Helper,
        private educationLevelService: EducationLevelService,
        private _notificationsService: NotificationsService
    ) {
        super();
    }

    ngOnInit(): void {
        this.activatedRoute.params.subscribe(
            params => {
                let name = params['name'];
                this.model.name = this.helper.base64Decode(name);
                this.educationLevelId = params['id'];
            }
        );

    }

    onSubmit() {
        jQuery("#educationLevelFormButton").button('loading');
        this.educationLevelService.update(this.model, this.educationLevelId).subscribe(
            response => {
                jQuery("#educationLevelFormButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            },error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#educationLevelFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrio un error al tratar de actualizar la información");
            }
        )
    }

}