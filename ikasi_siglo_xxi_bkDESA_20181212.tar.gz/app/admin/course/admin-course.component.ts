import {Component, OnInit} from "@angular/core";
import {Helper} from "../../helpers/helper";
import {CourseService} from "../../services/course.service";
import {ActivatedRoute} from "@angular/router";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/course/index.html',
    providers: [CourseService]
})

export class AdminCourseComponent extends Helper implements OnInit{
    public loading;
    // Total de páginas
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    // Página actual
    public page;
    // Array de cursos
    public courses = [];

    constructor(
        private _courseService: CourseService,
        private _activatedRoute: ActivatedRoute
    ) {
        super();
    }

    ngOnInit(): void {
        this.loading = true;
        this._activatedRoute.params.subscribe(
            params => {
                this.page = params['page'];

                if (!this.page) {
                    this.page = 1;
                }

                this._courseService.index(this.page).subscribe(
                    response => {
                        this.courses = response.data;
                        this.pages = [];

                        //noinspection TypeScriptUnresolvedVariable
                        for (let i = 0; i < response.total_pages; i++) {
                            this.pages.push(i);
                        }
                        this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                        //noinspection TypeScriptUnresolvedVariable
                        this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                        this.loading = false;
                    }, error => {
                        console.log(error);
                    }
                );
            });
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-course").addClass("active");
    }
}