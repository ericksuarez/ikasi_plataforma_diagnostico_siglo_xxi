import {Component, OnInit, Inject}  from "@angular/core";
import {CourseService}              from "../../services/course.service";
import {ActivatedRoute}             from "@angular/router";
import {AuthService}                from "../../services/auth.service";
import {APP_CONFIG, IAppConfig}     from "../../app.config";
import {UploadService}              from "../../services/upload.service";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/course/view.html',
    providers: [CourseService, UploadService]
})

export class AdminCourseViewComponent implements OnInit {
    public loading;
    public course = {
        name: null,
        description: null,
        educationLevel: {
            name: null
        },
        speciality: {
            name: null
        },
        teacherFunction: {
            name: null
        },
        link: null,
        image: null
    };
    public ready = false;
    public filesToUpload: Array<File>;
    public resultUpload;
    private url;
    private controller = "/course";
    private token;
    public courseId;
    public urlResource;

    constructor(private _courseService: CourseService,
                private _activatedRoute: ActivatedRoute,
                private authService: AuthService,
                private _uploadService: UploadService,
                @Inject(APP_CONFIG) private config: IAppConfig) {
        this.url = config.apiEndPoint + this.controller;
        this.token = authService.getToken();
        this.urlResource = config.apiEndPointUploads;
    }

    ngOnInit(): void {
        this.loading = true;
        //noinspection TypeScriptUnresolvedFunction
        jQuery("body").tooltip({
            selector: '[data-toggle="tooltip"]'
        });

        this._activatedRoute.params.subscribe(params => {
            this.courseId = params['id'];
            this._courseService.view(this.courseId).subscribe(
                response => {
                    this.course = response;
                    this.loading = false;
                }
            )
        });
    }

    loadFile(event): void {
        let input = event.target;
        if (input.files.length == 0) {
            return;
        }
        this.filesToUpload = <Array<File>>input.files;
        let reader = new FileReader();
        reader.onload = () => {
            let dataURL = reader.result;
            jQuery('.preview').attr('src', dataURL);
        };
        reader.readAsDataURL(input.files[0]);
        this.ready = true;
    }

    upload(): void {
        let _url = this.url + "/upload-image/" + this.courseId;
        this._uploadService.makeFileRequest(this.token, _url, ['image'], this.filesToUpload).then(
            (result) => {
                this.resultUpload = result;
            }, (error) => {
                console.log(error);
            }
        );
    }
}