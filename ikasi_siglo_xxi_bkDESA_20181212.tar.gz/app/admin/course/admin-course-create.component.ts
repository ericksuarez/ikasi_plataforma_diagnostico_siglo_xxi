import {Component, OnInit}          from "@angular/core";
import {CourseService}              from "../../services/course.service";
import {Course}                     from "../../models/course";
import {SpecialtyService}           from "../../services/specialty.service";
import {EducationLevelService}      from "../../services/education-level.service";
import {TeacherFunctionService}     from "../../services/teacher-function.service";
import {NotificationsService}       from "angular2-notifications";
import {Router}                     from "@angular/router";
import {SkillCenturyService}        from "../../services/skill-century.service";
import {SkillCenturyAreaService}    from "../../services/skill-century-area.service";
import {IneeService} from "../../services/inee.service";

declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/course/create.html',
    providers: [CourseService, SpecialtyService, EducationLevelService, TeacherFunctionService, SkillCenturyService, SkillCenturyAreaService, NotificationsService, IneeService]
})

export class AdminCourseCreateComponent implements OnInit {
    public model = new Course();
    public title = 'Nuevo';
    public specialty_list;
    public education_level_list;
    public teacher_function_list;
    private selector;
    public suggestion_century = 1;
    public suggestion_inee = 2;
    public skills;
    public areas = [];
    public optionsChecked = [];
    public dimension_list = [];

    constructor(private _courseService: CourseService,
                private _specialtyService: SpecialtyService,
                private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _notificationsService: NotificationsService,
                private _router: Router,
                private _skillCenturyService: SkillCenturyService,
                private _skillCenturyAreaService: SkillCenturyAreaService,
                private _ineeService: IneeService) {
    }

    ngOnInit(): void {
        this.selector = jQuery("#validator-dimension-ckeditor");

        this._specialtyService.getList().subscribe(
            response => {
                this.specialty_list = response;
            }, error => {
                console.log("Error al cargar las especialidades");
            }
        );

        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );

        this._skillCenturyService.findAll(-1).subscribe(
            response => {
                this.skills = response.data;
            }, error => {
                console.log(error);
            }
        );
    }

    onSubmit(): void {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#courseFormButton").button('loading');
        this.model.area_century = this.optionsChecked;
        this._courseService.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#courseFormButton").button('reset');
                if (response.status == 'success') {
                    this._router.navigate(['/admin/course/view', response.id]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#courseFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un error al guardar los datos");
            }
        )
    }

    //noinspection JSUnusedGlobalSymbols
    onChange(event) {
        if (event.length > 0) {
            this.selector.removeClass('custom-ckeditor-invalid');
            this.selector.addClass('custom-ckeditor-valid');
        } else {
            this.selector.removeClass('custom-ckeditor-valid');
            this.selector.addClass('custom-ckeditor-invalid');
        }
    }

    showAreas(skillId) {
        this.areas = [];
        this.optionsChecked = [];
        this._skillCenturyAreaService.findAll(skillId, -1).subscribe(
            response => {
                this.areas = response.data;
            }, error => {
                console.log(error);
            }
        )
    }

    updateSelectedOptions(area, event): void {
        if (event.target.checked) {
            this.optionsChecked.push(area.id);
        } else if (!event.target.checked) {
            let index = this.optionsChecked.indexOf(area.id);
            this.optionsChecked.splice(index, 1);
        }
    }

    /**
     * Fill select dimensions
     * @param teacher_function
     */
    showDimensions(teacher_function): void {
        if(!teacher_function) {
            return;
        }
        this.dimension_list = [];
        this._ineeService.getList(this.model.education_level, teacher_function).subscribe(
            response => {
                this.dimension_list = response;
                console.log(response);
            }
        );
    }
}