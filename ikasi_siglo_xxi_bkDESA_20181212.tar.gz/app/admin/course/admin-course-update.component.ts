import {Component, OnInit}      from "@angular/core";
import {Course}                 from "../../models/course";
import {CourseService}          from "../../services/course.service";
import {ActivatedRoute, Router}         from "@angular/router";
import {SpecialtyService}       from "../../services/specialty.service";
import {EducationLevelService}  from "../../services/education-level.service";
import {TeacherFunctionService} from "../../services/teacher-function.service";
import {NotificationsService}   from "angular2-notifications";
import {SkillCenturyService} from "../../services/skill-century.service";
import {SkillCenturyAreaService} from "../../services/skill-century-area.service";
import {IneeService} from "../../services/inee.service";
declare let jQuery: any;

@Component({
    templateUrl: 'app/views/admin/course/create.html',
    providers: [CourseService, SpecialtyService, EducationLevelService, TeacherFunctionService, SkillCenturyService, SkillCenturyAreaService, NotificationsService, IneeService]
})

export class AdminCourseUpdateComponent implements OnInit {
    public model = new Course();
    public title = 'Actualizar';
    public specialty_list;
    public education_level_list;
    public teacher_function_list;
    public suggestion_century = 1;
    public suggestion_inee = 2;
    private selector;
    public skills;
    public courseId;
    public areas = [];
    public optionsChecked = [];
    public dimension_list = [];

    constructor(private _courseService: CourseService,
                private _specialtyService: SpecialtyService,
                private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _notificationsService: NotificationsService,
                private _activatedRoute: ActivatedRoute,
                private _skillCenturyService: SkillCenturyService,
                private _skillCenturyAreaService: SkillCenturyAreaService,
                private _router: Router,
                private _ineeService: IneeService) {
    }

    ngOnInit(): void {
        this.selector = jQuery("#validator-dimension-ckeditor");

        this._specialtyService.getList().subscribe(
            response => {
                this.specialty_list = response;
            }, error => {
                console.log("Error al cargar las especialidades");
            }
        );

        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );

        this._skillCenturyService.findAll(-1).subscribe(
            response => {
                this.skills = response.data;
            }, error => {
                console.log(error);
            }
        );

        this._activatedRoute.params.subscribe(params => {
            this.courseId = params['id'];
            this._courseService.view(this.courseId).subscribe(
                response => {
                    this.model = response;
                    this.model.area_century = JSON.parse(response.areaCenturyIds);
                    this.model.teacher_function = response.teacherFunction.id;
                    this.model.education_level = response.educationLevel.id;
                    this.model.specialty = response.speciality.id;
                    if (response.typeSuggestion == this.suggestion_century) {
                        jQuery('#suggestion_century').trigger("click");
                    } else if (response.typeSuggestion == this.suggestion_inee) {
                        jQuery('#suggestion_inee').trigger("click");
                    }
                    // this.model.type_suggestion = parseInt(response.typeSuggestion);
                    if(response.skillCentury) {
                        this.model.skill_century = response.skillCentury.id;
                        this.showAreas(response.skillCentury.id, true);
                    }

                    if(response.dimension) {
                        this.showDimensions(this.model.teacher_function, true, response.dimension.id);
                    }
                }
            )
        });
    }

    onSubmit(): void {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#courseFormButton").button('loading');
        this.model.area_century = this.optionsChecked;
        this._courseService.update(this.model, this.courseId).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#courseFormButton").button('reset');
                if (response.status == 'success') {
                    //noinspection JSIgnoredPromiseFromCall
                    this._router.navigate(['/admin/course/view', this.courseId]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#courseFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un error al actualizar el curso");
            });
    }

    onChange(event): void {
        if (event.length > 0) {
            this.selector.removeClass('custom-ckeditor-invalid');
            this.selector.addClass('custom-ckeditor-valid');
        } else {
            this.selector.removeClass('custom-ckeditor-valid');
            this.selector.addClass('custom-ckeditor-invalid');
        }
    }

    showAreas(skillId, onLoad = false) {
        this.areas = [];
        this.optionsChecked = [];
        this._skillCenturyAreaService.findAll(skillId, -1).subscribe(
            response => {
                this.areas = response.data;

                if (onLoad) {
                    setTimeout(() => this.updateSelectedCheckbox(), 500);
                }

            }, error => {
                console.log(error);
            }
        )
    }

    updateSelectedCheckbox() {
        for (let _selectedArea of this.model.area_century) {
            for (let area of this.areas) {
                if (_selectedArea == area.id) {
                    jQuery("#area-" + area.id).trigger("click");
                }
            }
        }
    }

    updateSelectedOptions(area, event): void {
        if (event.target.checked) {
            this.optionsChecked.push(area.id);
        } else if (!event.target.checked) {
            let index = this.optionsChecked.indexOf(area.id);
            this.optionsChecked.splice(index, 1);
        }
    }

    /**
     * Fill select dimensions
     * @param teacher_function
     * @param onLoad
     * @param dimensionId
     */
    showDimensions(teacher_function, onLoad = false, dimensionId = null): void {
        if(!teacher_function) {
            return;
        }
        this.dimension_list = [];
        this._ineeService.getList(this.model.education_level, teacher_function).subscribe(
            response => {
                this.dimension_list = response;
                if(onLoad) {
                    setTimeout(() => {
                        jQuery('#dim-' + dimensionId).trigger("click");
                    }, 1000);
                }
            }
        );
    }
}