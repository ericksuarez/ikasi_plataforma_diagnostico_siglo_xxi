import {Component} from "@angular/core";
import {CatalogForm} from "../../models/catalog_form";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {TeacherFunctionService} from "../../services/teacher-function.service";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/teacher-function/create.html',
    providers: [TeacherFunctionService, NotificationsService]
})

export class AdminTeacherFunctionCreateComponent {

    model = new CatalogForm();
    teacherFunctionList = [];
    options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(private educationLevelService: TeacherFunctionService, private _notificationsService: NotificationsService) {
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#teacherFunctionFormButton").button('loading');
        this.educationLevelService.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#teacherFunctionFormButton").button('reset');
                if(response.status == 'success') {
                    this.teacherFunctionList.push(response);
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        )
    }
}