import {Component, OnInit}      from "@angular/core";
import {CatalogForm}            from "../../models/catalog_form";
import {IneeService}            from "../../services/inee.service";
import {ActivatedRoute}         from "@angular/router";
import {NotificationsService}   from "angular2-notifications/src/notifications.service";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-inee/dimension/add_indicator.html',
    providers: [IneeService, NotificationsService]
})

export class AdminIndicatorCreateComponent implements OnInit {
    public model = new CatalogForm();

    private selector;

    public parameter = {
        id: null,
        name: null,
        dimension: {
            id: 0
        }
    };

    public loading;

    public indicators = [];

    // Configuración para las notificaciones
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(private _ineeService: IneeService,
                private _activatedRoute: ActivatedRoute,
                private _notificationsService: NotificationsService) {
    }

    ngOnInit(): void {
        this.loading = true;
        this.selector = jQuery("#validator-dimension-ckeditor");

        this._activatedRoute.params.subscribe(
            params => {
                let id = params['id'];

                this._ineeService.getParameter(id).subscribe(
                    response => {
                        this.parameter = response.parameter;
                        this.indicators = response.indicators;
                        this.loading = false;
                    }
                );
            }
        );
    }

    onChange(event) {
        if (event.length > 0) {
            this.selector.removeClass('custom-ckeditor-invalid');
            this.selector.addClass('custom-ckeditor-valid');
        } else {
            this.selector.removeClass('custom-ckeditor-valid');
            this.selector.addClass('custom-ckeditor-invalid');
        }
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#parameterFormButton").button('loading');
        this._ineeService.createIndicator(this.model, this.parameter.id).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#parameterFormButton").button('reset');
                if (response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
                    this.indicators.push(response.data);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#parameterFormButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un error al guardar los datos");
            }
        )
    }
}