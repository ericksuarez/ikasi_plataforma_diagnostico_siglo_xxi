import {Component, OnInit, Inject} from "@angular/core";
import {SkillIne} from "../../models/skill-inee";
import {EducationLevelService} from "../../services/education-level.service";
import {TeacherFunctionService} from "../../services/teacher-function.service";
import {UploadService} from "../../services/upload.service";
import {IAppConfig, APP_CONFIG} from "../../app.config";
import {AuthService} from "../../services/auth.service";
import {IneeService} from "../../services/inee.service";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-inee/import.html',
    providers: [EducationLevelService, TeacherFunctionService, UploadService, IneeService]
})

export class AdminImportIneeComponent implements OnInit {
    public model = new SkillIne();
    public education_level_list = [];
    public teacher_function_list = [];
    public dimension_list = [];
    public parameter_list = [];
    public filesToUpload: Array<File>;
    public ready = false;
    private url;
    private controller = "/inee";
    private token;
    public resultUpload;

    constructor(private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _uploadService: UploadService,
                private _ineeService: IneeService,
                @Inject(APP_CONFIG) private config: IAppConfig,
                private authService: AuthService) {
        this.url = config.apiEndPoint + this.controller;
        this.token = authService.getToken();
    }

    ngOnInit(): void {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-inee").addClass("active");
        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );
    }

    loadFile(event): void {
        let input = event.target;
        if (input.files.length == 0) {
            return;
        }
        this.filesToUpload = <Array<File>>input.files;
        let reader = new FileReader();
        reader.onload = () => {
            let dataURL = reader.result;
            jQuery('.preview').attr('src', dataURL);
        };
        reader.readAsDataURL(input.files[0]);
        this.ready = true;
    }

    upload(): void {
        let _url = this.url + "/import";
        this._uploadService.makeFileRequest(this.token, _url, ['file', JSON.stringify(this.model)], this.filesToUpload).then(
            (result) => {
                this.resultUpload = result;
            }, (error) => {
                console.log(error);
            }
        );
    }

    resetForm(): void {
        this.model.teacher_function = "";
        this.model.dimension = "";
        this.model.parameter = "";
        this.dimension_list = [];
        this.parameter_list = [];
    }

    showDimensions(teacher_function): void {
        this.dimension_list = [];
        this.parameter_list = [];
        this._ineeService.getList(this.model.education_level, teacher_function).subscribe(
            response => {
                this.dimension_list = response;
            }
        );
    }

    showParameters(dimensionId): void {
        this.parameter_list = [];
        this._ineeService.getListParameter(dimensionId).subscribe(
            response => {
                this.parameter_list = response;
            }
        );
    }
}