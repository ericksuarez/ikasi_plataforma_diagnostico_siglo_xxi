import {Component, OnInit}  from "@angular/core";
import {EducationLevelService} from "../../services/education-level.service";
import {TeacherFunctionService} from "../../services/teacher-function.service";
import {IneeService} from "../../services/inee.service";
import {Dimension} from "../../models/dimension";

declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-inee/index.html',
    providers: [EducationLevelService, TeacherFunctionService, IneeService]
})

export class AdminSkillIneeComponent implements OnInit{
    public model = new Dimension();
    public education_level_list;
    public teacher_function_list;
    public dimensions = [];

    public colors = [
        {
            dimension: '#97B9E4',
            parameter: '#DCE8F6',
            indicator: '#EBF1F9'
        },
        {
            dimension: '#AB73D4',
            parameter: '#E1D0F0',
            indicator: '#F4ECF8'
        },
        {
            dimension: '#FF9225',
            parameter: '#FFE7CF',
            indicator: '#FFF3E7'
        },
        {
            dimension: '#31928B',
            parameter: '#B5E4E1',
            indicator: '#DAF1EF'
        },
        {
            dimension: '#61C52B',
            parameter: '#D2F0C1',
            indicator: '#E8F8DF'
        }
    ];

    constructor(private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _ineeService: IneeService){
    }

    ngOnInit(): void {
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-inee").addClass("active");

        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#dimensionButton").button('loading');
        this._ineeService.filterDimension(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#dimensionButton").button('reset');
                this.dimensions = response;
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#dimensionButton").button('reset');
            }
        )
    }
}