import {Component, OnInit}      from "@angular/core";
import {Dimension}              from "../../models/dimension";
import {EducationLevelService}  from "../../services/education-level.service";
import {TeacherFunctionService} from "../../services/teacher-function.service";
import {IneeService}            from "../../services/inee.service";
import {NotificationsService}   from "angular2-notifications/src/notifications.service";
import {Router} from "@angular/router";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-inee/dimension/create.html',
    providers: [EducationLevelService, TeacherFunctionService, IneeService, NotificationsService]
})

export class AdminDimensionCreateComponent implements OnInit {
    public model = new Dimension();
    public education_level_list;
    public teacher_function_list;
    private selector;
    // Configuración para las notificaciones
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(private _educationLevelService: EducationLevelService,
                private _teacherFunctionService: TeacherFunctionService,
                private _ineeService: IneeService,
                private _notificationsService: NotificationsService,
                private _router: Router) {
    }

    ngOnInit(): void {
        this.selector = jQuery("#validator-dimension-ckeditor");
        this._educationLevelService.getList().subscribe(
            response => {
                this.education_level_list = response;
            }, error => {
                console.log("Error al cargar los niveles");
            }
        );

        this._teacherFunctionService.getList().subscribe(
            response => {
                this.teacher_function_list = response;
            }, error => {
                console.log("Error al cargar las funciones");
            }
        );
    }

    onChange(event) {
        if (event.length > 0) {
            this.selector.removeClass('custom-ckeditor-invalid');
            this.selector.addClass('custom-ckeditor-valid');
        } else {
            this.selector.removeClass('custom-ckeditor-valid');
            this.selector.addClass('custom-ckeditor-invalid');
        }
    }

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#dimensionButton").button('loading');
        this._ineeService.createDimension(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#dimensionButton").button('reset');
                if(response.status == 'success') {
                    this._router.navigate(['/admin/skill-inee/parameter/create', response.id]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }, error => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#dimensionButton").button('reset');
                this._notificationsService.error("Error", "Ocurrió un error al guardar los datos");
            }
        )
    }
}