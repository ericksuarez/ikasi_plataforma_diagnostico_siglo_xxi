import {NgModule}                                       from '@angular/core';
import {CommonModule}                                   from '@angular/common';
import {AdminComponent}                                 from './admin.component';
import {AdminDashboardComponent}                        from './admin-dashboard.component';
import {AdminRoutingModule}                             from './admin-routing.module';
import {AdminCourseComponent}                           from "./course/admin-course.component";
import {AdminEvaluationComponent}                       from "./evaluation/admin-evaluation.component";
import {AdminTeacherComponent}                          from "./teacher/admin-teacher.component";
import {AdminSpecialityComponent}                       from "./speciality/admin-speciality.component";
import {AdminLevelEducationComponent}                   from "./level-education/admin-level-education.component";
import {AdminTeacherFunctionComponent}                  from "./teacher-function/admin-teacher-function.component";
import {AdminSkillCenturyComponent}                     from "./skill-century/admin-skill-century.component";
import {AdminSkillIneeComponent}                        from "./skill-inee/admin-skill-inee.component";
import {AdminSpecialityCreateComponent}                 from "./speciality/admin-speciality-create.component";
import {FormsModule}                                    from "@angular/forms";
import {SimpleNotificationsModule}                      from "angular2-notifications/src/simple-notifications.module";
import {AdminLevelEducationCreateComponent}             from "./level-education/admin-level-education-create.component";
import {AdminTeacherFunctionCreateComponent}            from "./teacher-function/admin-teacher-function-create.component";
import {AdminTeacherProfileComponent}                   from "./teacher/admin-teacher-profile.component";
import {AdminTeacherUpdateComponent}                    from "./teacher/admin-teacher-update.component";
import {AdminCourseCreateComponent}                     from "./course/admin-course-create.component";
import {CKEditorModule}                                 from "ng2-ckeditor";
import {AdminDimensionCreateComponent}                  from "./skill-inee/admin-skill-inee-create-dimension.component";
import {AdminCreateParameterComponent}                  from "./skill-inee/admin-create-parameter.component";
import {AdminIndicatorCreateComponent}                  from "./skill-inee/admin-indicator-create.component";
import {AdminCourseViewComponent}                       from "./course/admin-course-view.component";
import {AdminCourseUpdateComponent}                     from "./course/admin-course-update.component";
import {AdminSkillCenturyCreateComponent}               from "./skill-century/admin-skill-century-create.component";
import {AdminSkillCenturyEditComponent}                 from "./skill-century/admin-skill-century-edit.component";
import {AdminSkillCenturyAreaCreateComponent}           from "./skill-century/area/area-century.create.component";
import {AdminSkillCenturyAreaViewComponent}             from "./skill-century/area/area-century.view.component";
import {AdminSkillCenturyAreaEditComponent}             from "./skill-century/area/area-century.edit.component";
import {AdminProfileComponent}                          from "./components/admin-profile.component";
import {AdminSkillCenturyCategoryComponent}             from "./skill-century/categories/admin-skill-century-categories.component";
import {AdminSkillCenturyEditCategoryComponent}         from "./skill-century/categories/admin-skill-century-edit-categories.component";
import {AdminSkillCenturyCreateCategoryComponent}       from "./skill-century/categories/admin-skill-century-create-category.component";
import {SkillCenturyAnswerByCategoryComponent}          from "./skill-century/answer-by-category/skill-century-answer-by-category.component";
import {SkillCenturyCreateAnswerByCategoryComponent}    from "./skill-century/answer-by-category/skill-century-create-answer-by-category.component";
import {SkillCenturyEditAnswerCategoryComponent}        from "./skill-century/answer-by-category/skill-century-edit-answer-by-category.component";
import {SkillCenturyViewQuestionCenturyComponent}       from "./skill-century/question-century/skill-century-view-question-century.component";
import {SkillCenturyCreateQuestionCenturyComponent}     from "./skill-century/question-century/skill-century-create-question-century.component";
import {SkillCenturyAnswerByQuestionComponent}          from "./skill-century/answer-by-question/skill-century-answer-by-question.component"
import {AnswerQuestionCenturyCreateComponent}           from "./skill-century/answer-by-question/create-anser-by-question.component"
import {SkillCenturyImportQuestionCenturyComponent}     from "./skill-century/question-century/skill-century-import-question-century.component";
import {AdminTeacherPreRegisterComponent}               from "./teacher/admin-teacher-preregister.component";
import {AdminTeacherImportComponent}                    from "./teacher/admin-teacher-import.component";
import {AdminImportIneeComponent}                       from "./skill-inee/admin-import-inee.component";
import {AdminIneeEvaluationComponent}                   from "./inee/evaluation/admin-inee-evaluation.component";
import {AdminIneeEvaluationCreateComponent}             from "./inee/evaluation/admin-inee-evaluation-create.component";
import {AdminIneeEvaluationImportComponent}             from "./inee/evaluation/admin-inee-evaluation-import.component";
import {AdminIneeEvaluationUpdateComponent}             from "./inee/evaluation/admin-inee-evaluation-update.component";
import {AdminSpecialityUpdateComponent} from "./speciality/admin-speciality-update.component";
import {AdminLevelEducationUpdateComponent} from "./level-education/admin-level-education-update.component";
import {AdminTeacherFunctionUpdateComponent} from "./teacher-function/admin-teacher-function-update.component";

@NgModule({
    imports: [
        CommonModule,
        AdminRoutingModule,
        FormsModule,
        SimpleNotificationsModule,
        CKEditorModule
    ],
    declarations: [
        AdminComponent,
        AdminDashboardComponent,
        AdminProfileComponent,
        AdminCourseComponent,
        AdminCourseCreateComponent,
        AdminCourseViewComponent,
        AdminCourseUpdateComponent,
        AdminEvaluationComponent,
        AdminTeacherComponent,
        AdminTeacherProfileComponent,
        AdminSpecialityComponent,
        AdminSpecialityCreateComponent,
        AdminSpecialityUpdateComponent,
        AdminLevelEducationComponent,
        AdminLevelEducationCreateComponent,
        AdminLevelEducationUpdateComponent,
        AdminTeacherFunctionComponent,
        AdminTeacherFunctionCreateComponent,
        AdminTeacherUpdateComponent,
        AdminSkillCenturyComponent,
        AdminSkillIneeComponent,
        AdminDimensionCreateComponent,
        AdminCreateParameterComponent,
        AdminIndicatorCreateComponent,
        AdminSkillCenturyCreateComponent,
        AdminSkillCenturyEditComponent,
        AdminSkillCenturyAreaCreateComponent,
        AdminSkillCenturyAreaViewComponent,
        AdminSkillCenturyAreaEditComponent,
        AdminSkillCenturyCategoryComponent,
        AdminSkillCenturyEditCategoryComponent,
        AdminSkillCenturyCreateCategoryComponent,
        SkillCenturyAnswerByCategoryComponent,
        SkillCenturyCreateAnswerByCategoryComponent,
        SkillCenturyEditAnswerCategoryComponent,
        SkillCenturyViewQuestionCenturyComponent,
        SkillCenturyCreateQuestionCenturyComponent,
        SkillCenturyAnswerByQuestionComponent,
        AnswerQuestionCenturyCreateComponent,
        SkillCenturyImportQuestionCenturyComponent,
        AdminTeacherPreRegisterComponent,
        AdminTeacherImportComponent,
        AdminImportIneeComponent,
        AdminIneeEvaluationComponent,
        AdminIneeEvaluationCreateComponent,
        AdminIneeEvaluationImportComponent,
        AdminIneeEvaluationUpdateComponent,
        AdminTeacherFunctionUpdateComponent
    ]
})

export class AdminModule {
}
