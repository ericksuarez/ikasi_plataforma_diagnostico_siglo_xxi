import {Component, OnInit} from "@angular/core";
import {SkillCenturyService} from "../../services/skill-century.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute, Router} from "@angular/router";
import {SkillCentury} from "../../models/SkillCentury";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/edit.html',
    providers : [SkillCenturyService, NotificationsService]
})

export class AdminSkillCenturyEditComponent implements OnInit{

	public skill = new SkillCentury("","");
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(
    	private _skillCenturyService: SkillCenturyService, 
    	private _notificationsService: NotificationsService,
        private _route: ActivatedRoute,
		private _router : Router
        ) {
    }

    ngOnInit(){
        this._route.params.subscribe(params => {
			this.skill.name = params["name"];
			this.skill.id = params["id"];
        });
    }
	
	onSubmit(){
		this._notificationsService.info("Guardando", "...");
		this._skillCenturyService.edit(this.skill).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#skillFormButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
					this._router.navigate(["/admin/skill-century/index"]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        )
	}
}