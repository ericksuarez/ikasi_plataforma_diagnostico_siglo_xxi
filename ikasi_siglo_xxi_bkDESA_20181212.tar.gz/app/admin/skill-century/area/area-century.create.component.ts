import {Component, OnInit} from "@angular/core";
import {SkillCenturyAreaService} from "../../../services/skill-century-area.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute} from "@angular/router";
import {SkillArea} from "../../../models/SkillArea";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/area_create.html',
    providers : [SkillCenturyAreaService, NotificationsService]
})
export class AdminSkillCenturyAreaCreateComponent implements OnInit{

	public model = new SkillArea(0,"",0,0,0,0,0,0);
	public skillId = 0;
    public skills = [];
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
	
	constructor(
    	private _skillCenturyAreaService: SkillCenturyAreaService, 
    	private _notificationsService: NotificationsService,
		private activatedRoute : ActivatedRoute
		) {
    }
	
	ngOnInit(){
		this.activatedRoute.params.subscribe(params => {
			this.skillId = params['id'];
		});
		this.model.skill_century_id = this.skillId;
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-siglo-xxi").addClass("active");
	}

    

    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#skillFormButton").button('loading');
		
        this._skillCenturyAreaService.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#skillFormButton").button('reset');
                if(response.status == 'success') {
                    this.skills.push(response);
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        );
    }
	
}
