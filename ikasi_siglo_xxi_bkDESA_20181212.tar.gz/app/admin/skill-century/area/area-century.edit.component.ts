import {Component, OnInit} from "@angular/core";
import {SkillCenturyAreaService} from "../../../services/skill-century-area.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute, Router} from "@angular/router";
import {SkillArea} from "../../../models/SkillArea";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/area_create.html',
	providers : [SkillCenturyAreaService, NotificationsService]
})

export class AdminSkillCenturyAreaEditComponent implements OnInit{
	
	
	public model = new SkillArea(0,"",0,0,0,0,0,0);
	public areaId = 0;
	public skillId = 0;
    public skills = [];
	public editing = true;
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
	
	constructor(
    	private _skillCenturyAreaService: SkillCenturyAreaService, 
    	private _notificationsService: NotificationsService,
		private activatedRoute : ActivatedRoute,
		private _router : Router
		) {
    }

	ngOnInit(){
		this.activatedRoute.params.subscribe(params => {
			this.areaId = params['areaId'];
			this.skillId = params['skillId'];
			this._skillCenturyAreaService.areaDetail(this.areaId).subscribe(
			response => {
				if(response.status == "success"){
					let skill  = response.data;
					this.model.skill_century_id = skill.id; 
					this.model.name = skill.name;
					this.model.min_vulnerable =skill.minVulnerable;
					this.model.max_vulnerable =skill.maxVulnerable;
					this.model.min_competent = skill.minCompetent;
					this.model.max_competent =skill.maxCompetent, 
					this.model.min_optimum =skill.minOtimum;
					this.model.max_optimum = skill.maxOtimum;
				}
			});
		});
	}
	
	onSubmit(){
		this._notificationsService.info("Guardando", "...");
		this._skillCenturyAreaService.edit(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#skillFormButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
					this._router.navigate(["/admin/skill-century/skill-area/" + this.skillId]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        )
	}

	delete(){
		alert(this.areaId);
	}
}