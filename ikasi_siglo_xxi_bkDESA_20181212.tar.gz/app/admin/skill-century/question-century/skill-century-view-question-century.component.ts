import {Component, OnInit} from "@angular/core";
import {SkillCenturyQuestionCenturyService} from "../../../services/skill-century-question-century.service";
import {SkillCenturyService} from "../../../services/skill-century.service";
import {SkillCenturyAreaService} from "../../../services/skill-century-area.service";
import {SkillCenturyCategoryService} from "../../../services/skill-century-category.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../../helpers/helper";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/question-century/index.html',
    providers : [
		SkillCenturyQuestionCenturyService,
		SkillCenturyService,
		SkillCenturyAreaService,
		SkillCenturyCategoryService
	]
})

export class SkillCenturyViewQuestionCenturyComponent extends Helper implements OnInit{
	
	public questions = [];
    public loading;
    // Total de páginas
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    // Página actual
    public page;
	//status de la respuesta
	public estatus;
	//status message from server
	public message;
	public skills;
	public areas = [];
	public categories;
	public colors = [
		{
			skill: '#97B9E4',
			area: '#DCE8F6',
			category: '#EBF1F9',
			question: '#f1f7ff'
		},
		{
			skill: '#AB73D4',
			area: '#E1D0F0',
			category: '#F4ECF8',
			question: '#fbf3ff'
		},
		{
			skill: '#FF9225',
			area: '#FFE7CF',
			category: '#f9ede1',
			question: '#fff3e7'
		},
		{
			skill: '#31928B',
			area: '#B5E4E1',
			category: '#DAF1EF',
			question: '#e8fffd'
		},
		{
			skill: '#61C52B',
			area: '#D2F0C1',
			category: '#E8F8DF',
			question: '#efffe6'
		}
	];
	
	constructor(
		public _skillCenturyQuestionCenturyService : SkillCenturyQuestionCenturyService,
		public _skillCenturyService: SkillCenturyService,
		public _skillCenturyAreaService: SkillCenturyAreaService,
		public _skillCenturyCategoryService:SkillCenturyCategoryService,
	){super()}
	
	ngOnInit(): void {
		this.loading = true;

		this._skillCenturyCategoryService.findAll(-1).subscribe(
			response => {
				this.categories = response.data;

				if (this.categories.length == 0) {
					this.loading = false;
				}
			}, error => {
				console.log(error);
			}
		);

        this._skillCenturyService.findAll(-1).subscribe(
			response => {
				this.skills = response.data;

                if (this.skills.length == 0) {
                    this.loading = false;
                }

                for (let i = 0; i < this.skills.length; i++) {
                    this._skillCenturyAreaService.findAll(this.skills[i].id, -1).subscribe(
                        response => {
                            this.areas[this.skills[i].id] = response.data;
                            for(let j = 0 ; j < this.categories.length; j++){
                            	let areas = this.areas[this.skills[i].id];
                            	for(let k = 0; k < areas.length; k++){
                            		this.getQuestionsByAreaAndCategory(areas[k].id, this.categories[j].id);
								}
							}
                        }, error => {
                            this.loading = false;
                            console.log(error);
                        }
                    );
                }
            }, error => {
                console.log(error);
            }
        );
        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-catalog").addClass("active");
	}

	private getQuestionsByAreaAndCategory(areaId, categoryId){
		this.loading = false;
		this._skillCenturyQuestionCenturyService.findAll(areaId, categoryId).subscribe(
			response=>{
				this.questions[areaId + '_' + categoryId] = response.data;
			}, error => {
				console.log(error);
			}
		);
	}
}