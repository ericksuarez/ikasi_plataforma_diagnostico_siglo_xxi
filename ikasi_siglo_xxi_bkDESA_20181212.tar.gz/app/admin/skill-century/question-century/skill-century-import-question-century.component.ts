import {Component, OnInit} from "@angular/core";
import {SkillCenturyService} from "../../../services/skill-century.service";
import {SkillCenturyAreaService} from "../../../services/skill-century-area.service";
import {SkillCenturyCategoryService} from "../../../services/skill-century-category.service";
import {SkillCenturyQuestionCenturyService} from "../../../services/skill-century-question-century.service";
import {SkillQuestionCentury} from "../../../models/SkillCenturyQuestionCentury";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/question-century/import.html',
    providers : [
        SkillCenturyService,
        SkillCenturyAreaService,
        SkillCenturyCategoryService,
        SkillCenturyQuestionCenturyService
    ]
})

export class SkillCenturyImportQuestionCenturyComponent implements OnInit{

    public model = new SkillQuestionCentury(0,0,0,"");
    public skillId = 0;
    public skills = [];
    public areas = [];
    public questions = [];
    public categories = [];
    public loading = false;
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
    private filesToUpload: Array<File>
    private replace;
    public resultUpload;
    public error = false;

    constructor(
        private _skillCenturyAreaService: SkillCenturyAreaService,
        private _skillCenturyService: SkillCenturyService,
        private _skillCenturyCategoryService: SkillCenturyCategoryService,
        private _skillCenturyQuestionCentury: SkillCenturyQuestionCenturyService,
    ) {}

    ngOnInit(){
        this._skillCenturyService.findAll(-1).subscribe(
            response => {
                this.skills = response.data;
                this.loading = false;
            }, error => {
                console.log(error);
            }
        );
        this._skillCenturyCategoryService.findAll(-1).subscribe(
            response =>{
                this.categories = response.data;
                this.loading = false;
            }, error => {
                console.log(error);
            }
        );
    }

    showAreas(skillId){
        this.loading = true;
        this.areas = [];
        this._skillCenturyAreaService.findAll(skillId, -1).subscribe(
            response => {
                this.loading = false;
                this.areas= response.data;
            }, error => {
                console.log(error);
            }
        )
    }

    setAreaId(area_id){
        this.model.area_id = area_id;
        console.log(this.model);
    }

    setCategoryId(category_id){
        this.model.category_id = category_id;
        console.log(this.model);
    }

    setReplace(replace){
        this.replace = replace;
    }

    csvUploadToServer(fileInput: any){
        if(this.replace == 1 || this.replace == 0){
            if(confirm("¿Esta seguro de cargar este archivo?")){
                this.filesToUpload = <Array<File>>fileInput.target.files;
                this._skillCenturyQuestionCentury.makeFileRequest(['csv'], this.filesToUpload, this.model, this.replace).then(
                    (result) => {
                        this.resultUpload = result;
                        console.log(this.resultUpload);
                    }, (error) => {
                        console.log(error)
                    }
                );
            }
            this.error = false;
        } else {
            this.error = true;
        }
    }
}