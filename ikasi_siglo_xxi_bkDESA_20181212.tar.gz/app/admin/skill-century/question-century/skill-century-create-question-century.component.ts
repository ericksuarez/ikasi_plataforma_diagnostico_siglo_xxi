import {Component, OnInit} from "@angular/core";
import {SkillCenturyService} from "../../../services/skill-century.service";
import {SkillCenturyAreaService} from "../../../services/skill-century-area.service";
import {SkillCenturyCategoryService} from "../../../services/skill-century-category.service";
import {SkillCenturyQuestionCenturyService} from "../../../services/skill-century-question-century.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute} from "@angular/router";
import {SkillQuestionCentury} from "../../../models/SkillCenturyQuestionCentury";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/question-century/create.html',
    providers : [
		SkillCenturyService, 
		SkillCenturyAreaService, 
		SkillCenturyCategoryService,
		SkillCenturyQuestionCenturyService,
		NotificationsService
		]
})
export class SkillCenturyCreateQuestionCenturyComponent implements OnInit{

	//1er parametro id	
	//2do parametro area_id
	//3er parametro category_id
	//4to parametro name
	public model = new SkillQuestionCentury(0,0,0,"");
	public skillId = 0;
    public skills = [];
	public areas = [];
	public questions = [];
	public categories = [];
	public loading = true;
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
	
	constructor(
    	private _skillCenturyAreaService: SkillCenturyAreaService,
		private _skillCenturyService: SkillCenturyService, 
		private _skillCenturyCategoryService: SkillCenturyCategoryService,
		private _skillCenturyQuestionCentury: SkillCenturyQuestionCenturyService,
    	private _notificationsService: NotificationsService,
		private activatedRoute : ActivatedRoute
		) {
    }
	
	ngOnInit(){
		this._skillCenturyService.findAll(-1).subscribe(
                response => {
                    this.skills = response.data;
                    this.loading = false;
                }, error => {
                    console.log(error);
                }
        );
		this._skillCenturyCategoryService.findAll(-1).subscribe(
			response =>{
				this.categories = response.data;
				this.loading = false;
			}, error => {
				console.log(error);
			}
		);
	}
	
	onSubmit(){
		//noinspection TypeScriptValidateJSTypes
        jQuery("#skillFormButton").button('loading');
		
        this._skillCenturyQuestionCentury.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#questionFormButton").button('reset');
                if(response.status == 'success') {
                    this.questions.push(response);
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        );
	}
	
	showAreas(skillId){
		this.loading=true;
		this.areas = [];
		this._skillCenturyAreaService.findAll(skillId, -1).subscribe(
			response => {
				this.loading = false;				
				this.areas= response.data;
			}, error => {
				console.log(error);
			}
		)
	}
	
	setAreaId(area_id){
		this.model.area_id = area_id;
		console.log(this.model);
	}
	
	setCategoryId(category_id){
		this.model.category_id = category_id;
		console.log(this.model);
	}
	
}