import {Component, OnInit} from "@angular/core";
import {SkillCenturyAnswerCategoryService} from "../../../services/skill-century-answer-category.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute, Router} from "@angular/router";
import {SkillCenturyAnswerCategory} from "../../../models/SkillCenturyAnswerCategory";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/answer-by-category/create.html',
	providers : [SkillCenturyAnswerCategoryService, NotificationsService]
})

export class SkillCenturyEditAnswerCategoryComponent implements OnInit{
	public model = new SkillCenturyAnswerCategory(0,0,"",0);
	public answerId = 0;
	public categoryId = 0;
    public answers = [];
	public editing = true;
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
	
	constructor(
    	private _skillCenturyAnswerCategoryService: SkillCenturyAnswerCategoryService, 
    	private _notificationsService: NotificationsService,
		private activatedRoute : ActivatedRoute,
		private _router : Router
		) {
    }
	
	ngOnInit(){
		this.activatedRoute.params.subscribe(params => {
			this.answerId = params['answerId'];
			this.categoryId = params['categoryId'];
			this._skillCenturyAnswerCategoryService.answerDetail(this.answerId).subscribe(
			response => {
				if(response.status == "success"){
					let answer  = response.data;
					this.model.id = answer.id;
					this.model.category_id = answer.category.id;
					this.model.name = answer.name;
					this.model.value = answer.value;
				}
			});
		});
	}
	
	onSubmit(){
		this._notificationsService.info("Guardando", "...");
		this._skillCenturyAnswerCategoryService.edit(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#skillFormButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
					this._router.navigate(["/admin/skill-century/view-questions-by-category/" + this.categoryId]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        )
	}
}