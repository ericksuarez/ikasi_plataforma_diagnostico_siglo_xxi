import {Component, OnInit} from "@angular/core";
import {SkillCenturyAnswerCategoryService} from "../../../services/skill-century-answer-category.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../../helpers/helper";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/answer-by-category/index.html',
    providers : [SkillCenturyAnswerCategoryService]
})

export class SkillCenturyAnswerByCategoryComponent extends Helper implements OnInit{
	public answers;
    public loading;
    // Total de páginas
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    // Página actual
    public page;
	//id actual de skill
	public categoryId;
	//status de la respuesta
	public estatus;
	//status message from server
	public message;
	
	constructor(
		public _skillCenturyAnswerCategoryService : SkillCenturyAnswerCategoryService,
		private activatedRoute: ActivatedRoute
	){super()}
	
	ngOnInit(){
		this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.page = params['page'];
			this.categoryId = params['id'];
            if (!this.page) {
                this.page = 1;
            }
            this._skillCenturyAnswerCategoryService.findAll(this.categoryId, this.page).subscribe(
                response => {
                    this.answers = response.data;
					this.estatus = response.status;
					this.message = response.message;
                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }
					
					if(response.total_pages == 1){
						document.getElementById("paginator").style.display = "none";
					}					
					
                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });

        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-catalog").addClass("active");
	}

}