import {Component, OnInit} from "@angular/core";
import {SkillCenturyAnswerCategoryService} from "../../../services/skill-century-answer-category.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute} from "@angular/router";
import {SkillCenturyAnswerCategory} from "../../../models/SkillCenturyAnswerCategory";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/answer-by-category/create.html',
    providers : [SkillCenturyAnswerCategoryService, NotificationsService]
})
export class SkillCenturyCreateAnswerByCategoryComponent implements OnInit{
	//1er parametro id
	//2do parametro category_id
	//3er parametro name
	//4to parametro value
	public model = new SkillCenturyAnswerCategory(0,0,"",0);
	public categoryId = 0;
    public answers = [];
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
	
	constructor(
    	private _skillCenturyAnswerCategoryService: SkillCenturyAnswerCategoryService, 
    	private _notificationsService: NotificationsService,
		private activatedRoute : ActivatedRoute
		) {
    }
	
	ngOnInit(){
		this.activatedRoute.params.subscribe(params => {
			this.categoryId = params['id'];
		});
		this.model.category_id = this.categoryId;
	}
	
	onSubmit(){
		//noinspection TypeScriptValidateJSTypes
        jQuery("#answerFormButton").button('loading');
		
        this._skillCenturyAnswerCategoryService.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#answerFormButton").button('reset');
                if(response.status == 'success') {
                    this.answers.push(response);
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        );
	}
}