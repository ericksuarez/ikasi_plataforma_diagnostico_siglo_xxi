import {Component, OnInit} from "@angular/core";
import {SkillCenturyAnswerByQuestionService} from "../../../services/skill-century-answer-by-question.service";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
import {ActivatedRoute} from "@angular/router";
import {AnswerQuestionCentury} from "../../../models/AnswerQuestionCentury";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/answer-question/create.html',
    providers : [SkillCenturyAnswerByQuestionService, NotificationsService]
})
export class AnswerQuestionCenturyCreateComponent implements OnInit{

    public model = new AnswerQuestionCentury();
    public questionId = 0;
    public answers = [];
    public question;
    public loading = true;
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };

    constructor(
        private _skillCenturyAnswerByQuestionService: SkillCenturyAnswerByQuestionService,
        private _notificationsService: NotificationsService,
        private activatedRoute : ActivatedRoute
    ) {
    }

    ngOnInit(){
        this.activatedRoute.params.subscribe(params => {
            this.questionId = params['id'];
            this.question = params["question"];
        });
        this._skillCenturyAnswerByQuestionService.findAll(this.questionId, 1).subscribe(
            response => {
                if (response.status != "error") {
                    this.question = response.pregunta;
                    this.answers = response.data;
                }
                this.loading = false;
            }, error => {
                console.log(error);
            }
        );
        this.model.questionId = this.questionId;
    }



    onSubmit() {
        //noinspection TypeScriptValidateJSTypes
        jQuery("#skillFormButtonSave").button('loading');

        this._skillCenturyAnswerByQuestionService.create(this.model).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#skillFormButtonSave").button('reset');
                if(response.status == 'success') {
                    this.answers.push(response);
                    this._notificationsService.success(response.title, response.message);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        );

    }

}
