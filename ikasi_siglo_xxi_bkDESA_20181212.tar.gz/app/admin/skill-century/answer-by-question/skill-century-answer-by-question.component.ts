import {Component, OnInit} from "@angular/core";
import {SkillCenturyAnswerByQuestionService} from "../../../services/skill-century-answer-by-question.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../../helpers/helper";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/answer-question/index.html',
    providers : [SkillCenturyAnswerByQuestionService]
})

export class SkillCenturyAnswerByQuestionComponent extends Helper implements OnInit{
    public answers;
    public questionId;
    public loading;
    public page;
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    public pregunta;

    constructor(
        public _skillCenturyAnswerByQuestionService : SkillCenturyAnswerByQuestionService,
        private activatedRoute: ActivatedRoute
    ){super()}

    ngOnInit(){
        this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.questionId = params['id'];
            this.page = params['page'];
            if (!this.page) {
                this.page = 1;
            }
            this._skillCenturyAnswerByQuestionService.findAll(this.questionId, this.page).subscribe(
                response => {
                    this.pregunta = response.pregunta;
                    this.answers = response.data;

                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }

                    if(response.total_pages == 1){
                        document.getElementById("paginator").style.display = "none";
                    }

                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });

        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-catalog").addClass("active");
    }
}