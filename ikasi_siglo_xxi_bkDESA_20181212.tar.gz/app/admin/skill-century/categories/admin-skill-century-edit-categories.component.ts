import {Component, OnInit} from "@angular/core";
import {SkillCenturyCategoryService} from "../../../services/skill-century-category.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Helper} from "../../../helpers/helper";
import {SkillCenturyCategory} from "../../../models/SkillCenturyCategory";
import {NotificationsService} from "angular2-notifications/src/notifications.service";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/categories/create.html',
    providers : [SkillCenturyCategoryService, NotificationsService]
})

export class AdminSkillCenturyEditCategoryComponent extends Helper implements OnInit{
	public category = new SkillCenturyCategory(0,"");
    public categories = [];
	public editing = true;
    public options = {
        timeOut: 3000,
        lastOnBottom: true,
        clickToClose: true,
        maxLength: 0,
        maxStack: 7,
        showProgressBar: true,
        pauseOnHover: true,
        preventDuplicates: false,
        preventLastDuplicates: 'visible',
        rtl: false,
        animate: 'scale',
        position: ['left', 'bottom']
    };
	
	constructor(
    	private _skillCenturyCategoryService: SkillCenturyCategoryService, 
    	private _notificationsService: NotificationsService,
		private activatedRoute : ActivatedRoute,
		private _router : Router
		) {
		super();
    }
	
	ngOnInit(){
		this.activatedRoute.params.subscribe(params => {
			this.category.name = params['name'];
			this.category.skill_century_category_id = params['id'];
		});
	}
	
	onSubmit(){
		this._notificationsService.info("Guardando", "...");
		this._skillCenturyCategoryService.edit(this.category).subscribe(
            response => {
                //noinspection TypeScriptValidateJSTypes
                jQuery("#categoryFormButton").button('reset');
                if(response.status == 'success') {
                    this._notificationsService.success(response.title, response.message);
					this._router.navigate(["/admin/skill-century/categories"]);
                } else {
                    this._notificationsService.error(response.title, response.message);
                }
            }
        )
	}
}