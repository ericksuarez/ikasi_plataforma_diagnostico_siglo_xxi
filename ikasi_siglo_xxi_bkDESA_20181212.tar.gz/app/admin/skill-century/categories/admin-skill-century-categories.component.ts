import {Component, OnInit} from "@angular/core";
import {SkillCenturyCategoryService} from "../../../services/skill-century-category.service";
import {ActivatedRoute} from "@angular/router";
import {Helper} from "../../../helpers/helper";
declare var jQuery: any;

@Component({
    templateUrl: 'app/views/admin/skill-century/categories/index.html',
    providers : [SkillCenturyCategoryService]
})

export class AdminSkillCenturyCategoryComponent extends Helper implements OnInit{

	public categories;
    public loading;
    // Total de páginas
    public pages;
    // Página anterior
    public pagePrev = 1;
    // Siguiente página
    public pageNext = 1;
    // Página actual
    public page;
	
	constructor(
		public _skillCenturyCategoryService : SkillCenturyCategoryService,
		private activatedRoute: ActivatedRoute
	){super()}
	
	ngOnInit(){
		this.loading = true;
        this.activatedRoute.params.subscribe(params => {
            this.page = params['page'];
            if (!this.page) {
                this.page = 1;
            }
            this._skillCenturyCategoryService.findAll(this.page).subscribe(
                response => {
                    this.categories = response.data;
                    this.pages = [];

                    //noinspection TypeScriptUnresolvedVariable
                    for (let i = 0; i < response.total_pages; i++) {
                        this.pages.push(i);
                    }
					
					
                    this.pagePrev = (this.page > 1) ? (parseInt(this.page) - 1) : this.page;
                    //noinspection TypeScriptUnresolvedVariable
                    this.pageNext = (this.page < response.total_pages) ? (parseInt(this.page) + 1) : this.page;

                    this.loading = false;
                }, error => {
                    console.log(error);
                }
            );
        });

        jQuery("#main-navigation").find(">ul>li.active").removeClass("active");
        jQuery("#menu-catalog").addClass("active");
	}
}