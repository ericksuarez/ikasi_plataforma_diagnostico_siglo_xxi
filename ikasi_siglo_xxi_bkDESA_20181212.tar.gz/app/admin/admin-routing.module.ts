import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {AdminComponent} from './admin.component';
import {AdminDashboardComponent} from './admin-dashboard.component';
import {AuthGuard} from "../services/auth-guard.service";
import {AuthService} from "../services/auth.service";
import {AdminCourseComponent} from "./course/admin-course.component";
import {AdminEvaluationComponent} from "./evaluation/admin-evaluation.component";
import {AdminTeacherComponent} from "./teacher/admin-teacher.component";
import {AdminSpecialityComponent} from "./speciality/admin-speciality.component";
import {AdminLevelEducationComponent} from "./level-education/admin-level-education.component";
import {AdminTeacherFunctionComponent} from "./teacher-function/admin-teacher-function.component";
import {AdminSkillCenturyComponent} from "./skill-century/admin-skill-century.component";
import {AdminSkillIneeComponent} from "./skill-inee/admin-skill-inee.component";
import {AdminSpecialityCreateComponent} from "./speciality/admin-speciality-create.component";
import {AdminLevelEducationCreateComponent} from "./level-education/admin-level-education-create.component";
import {AdminTeacherFunctionCreateComponent} from "./teacher-function/admin-teacher-function-create.component";
import {AdminTeacherProfileComponent} from "./teacher/admin-teacher-profile.component";
import {AdminTeacherUpdateComponent} from "./teacher/admin-teacher-update.component";
import {AdminCourseCreateComponent} from "./course/admin-course-create.component";
import {AdminDimensionCreateComponent} from "./skill-inee/admin-skill-inee-create-dimension.component";
import {AdminCreateParameterComponent} from "./skill-inee/admin-create-parameter.component";
import {AdminIndicatorCreateComponent} from "./skill-inee/admin-indicator-create.component";
import {AdminCourseViewComponent} from "./course/admin-course-view.component";
import {AdminCourseUpdateComponent} from "./course/admin-course-update.component";
import {AdminSkillCenturyCreateComponent} from "./skill-century/admin-skill-century-create.component";
import {AdminSkillCenturyEditComponent} from "./skill-century/admin-skill-century-edit.component";
import {AdminSkillCenturyAreaViewComponent} from "./skill-century/area/area-century.view.component";
import {AdminSkillCenturyAreaCreateComponent} from "./skill-century/area/area-century.create.component";
import {AdminSkillCenturyAreaEditComponent} from "./skill-century/area/area-century.edit.component";
import {AdminProfileComponent} from "./components/admin-profile.component";
import {AdminSkillCenturyCategoryComponent} from "./skill-century/categories/admin-skill-century-categories.component";
import {AdminSkillCenturyEditCategoryComponent} from "./skill-century/categories/admin-skill-century-edit-categories.component";
import {AdminSkillCenturyCreateCategoryComponent} from "./skill-century/categories/admin-skill-century-create-category.component";
import {SkillCenturyAnswerByCategoryComponent} from "./skill-century/answer-by-category/skill-century-answer-by-category.component"
import {SkillCenturyCreateAnswerByCategoryComponent} from "./skill-century/answer-by-category/skill-century-create-answer-by-category.component";
import {SkillCenturyEditAnswerCategoryComponent} from "./skill-century/answer-by-category/skill-century-edit-answer-by-category.component";
import {SkillCenturyViewQuestionCenturyComponent} from "./skill-century/question-century/skill-century-view-question-century.component";
import {SkillCenturyCreateQuestionCenturyComponent} from "./skill-century/question-century/skill-century-create-question-century.component";
import {SkillCenturyAnswerByQuestionComponent} from "./skill-century/answer-by-question/skill-century-answer-by-question.component";
import {AnswerQuestionCenturyCreateComponent} from "./skill-century/answer-by-question/create-anser-by-question.component";
import {SkillCenturyImportQuestionCenturyComponent} from "./skill-century/question-century/skill-century-import-question-century.component";
import {AdminTeacherPreRegisterComponent} from "./teacher/admin-teacher-preregister.component";
import {AdminTeacherImportComponent} from "./teacher/admin-teacher-import.component";
import {AdminImportIneeComponent} from "./skill-inee/admin-import-inee.component";
import {AdminIneeEvaluationComponent} from "./inee/evaluation/admin-inee-evaluation.component";
import {AdminIneeEvaluationCreateComponent} from "./inee/evaluation/admin-inee-evaluation-create.component";
import {AdminIneeEvaluationImportComponent} from "./inee/evaluation/admin-inee-evaluation-import.component";
import {AdminIneeEvaluationUpdateComponent} from "./inee/evaluation/admin-inee-evaluation-update.component";
import {AdminSpecialityUpdateComponent} from "./speciality/admin-speciality-update.component";
import {AdminLevelEducationUpdateComponent} from "./level-education/admin-level-education-update.component";
import {AdminTeacherFunctionUpdateComponent} from "./teacher-function/admin-teacher-function-update.component";


@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: '',
                component: AdminComponent,
                canActivate: [AuthGuard],
                children: [
                    {
                        path: '',
                        canActivateChild: [AuthGuard],
                        children: [
                            {path: 'dashboard', component: AdminDashboardComponent},
                            {path: 'profile', component: AdminProfileComponent}
                        ]
                    },
                    {
                        path: 'course',
                        canActivateChild: [AuthGuard],
                        children: [
                            {path: '', redirectTo: '/admin/course/index', pathMatch: 'full', canActivate: [AuthGuard]},
                            {path: 'index', component: AdminCourseComponent},
                            {path: 'create', component: AdminCourseCreateComponent},
                            {path: 'view/:id', component: AdminCourseViewComponent},
                            {path: 'update/:id', component: AdminCourseUpdateComponent}
                        ]
                    },
                    {
                        path: 'evaluation',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: '',
                                redirectTo: '/admin/evaluation/index',
                                pathMatch: 'full',
                                canActivate: [AuthGuard]
                            },
                            {path: 'index', component: AdminEvaluationComponent}
                        ]
                    },
                    {
                        path: 'teacher',
                        canActivateChild: [AuthGuard],
                        children: [
                            {path: '', redirectTo: '/admin/teacher/index', pathMatch: 'full', canActivate: [AuthGuard]},
                            {path: 'index', component: AdminTeacherComponent},
                            {path: 'index/:page', component: AdminTeacherComponent},
                            {path: 'profile/:id', component: AdminTeacherProfileComponent},
                            {path: 'update/:id/:userId/:email/:status', component: AdminTeacherUpdateComponent},
                            {path: 'preregister', component: AdminTeacherPreRegisterComponent},
                            {path: 'preregister/:page', component: AdminTeacherPreRegisterComponent},
                            {path: 'import', component: AdminTeacherImportComponent}
                        ]
                    },
                    {
                        path: 'speciality',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: '',
                                redirectTo: '/admin/speciality/index',
                                pathMatch: 'full',
                                canActivate: [AuthGuard]
                            },
                            {path: 'index', component: AdminSpecialityComponent},
                            {path: 'index/:page', component: AdminSpecialityComponent},
                            {path: 'create', component: AdminSpecialityCreateComponent},
                            {path: 'update/:id/:name', component: AdminSpecialityUpdateComponent}
                        ]
                    },
                    {
                        path: 'level-education',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: '',
                                redirectTo: '/admin/level-education/index',
                                pathMatch: 'full',
                                canActivate: [AuthGuard]
                            },
                            {path: 'index', component: AdminLevelEducationComponent},
                            {path: 'index/:page', component: AdminLevelEducationComponent},
                            {path: 'create', component: AdminLevelEducationCreateComponent},
                            {path: 'update/:id/:name', component: AdminLevelEducationUpdateComponent}
                        ]
                    },
                    {
                        path: 'teacher-function',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: '',
                                redirectTo: '/admin/teacher-function/index',
                                pathMatch: 'full',
                                canActivate: [AuthGuard]
                            },
                            {path: 'index', component: AdminTeacherFunctionComponent},
                            {path: 'index/:page', component: AdminTeacherFunctionComponent},
                            {path: 'create', component: AdminTeacherFunctionCreateComponent},
                            {path: 'update/:id/:name', component: AdminTeacherFunctionUpdateComponent}
                        ]
                    },
                    {
                        path: 'skill-century',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: '',
                                redirectTo: '/admin/skill-century/index',
                                pathMatch: 'full',
                                canActivate: [AuthGuard]
                            },
                            {path: 'index', component: AdminSkillCenturyComponent},
                            {path: 'index/:page', component: AdminSkillCenturyComponent},
                            {path: 'create', component: AdminSkillCenturyCreateComponent},
                            {path: 'edit/:id/:name', component: AdminSkillCenturyEditComponent},
                            {path: 'skill-area/:id', component: AdminSkillCenturyAreaViewComponent},
                            {path: 'skill-area/:id/:page', component: AdminSkillCenturyAreaViewComponent},
                            {path: 'skill-create-area/:id', component: AdminSkillCenturyAreaCreateComponent},
                            {
                                path: 'skill-area/create',
                                redirectTo: '/admin/skill-century/index',
                                canActivate: [AuthGuard]
                            },
                            {path: 'skill-edit-area/:skillId/:areaId', component: AdminSkillCenturyAreaEditComponent},
                            {path: 'categories', component: AdminSkillCenturyCategoryComponent},
                            {path: 'categories/:page', component: AdminSkillCenturyCategoryComponent},
                            {path: 'edit-caregory/:id/:name', component: AdminSkillCenturyEditCategoryComponent},
                            {path: 'create-category', component: AdminSkillCenturyCreateCategoryComponent},
                            {path: 'view-questions-by-category/:id', component: SkillCenturyAnswerByCategoryComponent},
                            {
                                path: 'view-questions-by-category/:id/:page',
                                component: SkillCenturyAnswerByCategoryComponent
                            },
                            {
                                path: 'skill-create-answer-category/:id',
                                component: SkillCenturyCreateAnswerByCategoryComponent
                            },
                            {
                                path: 'edit-answer-category/:categoryId/:answerId',
                                component: SkillCenturyEditAnswerCategoryComponent
                            },
                            {path: 'view-question-century', component: SkillCenturyViewQuestionCenturyComponent},
                            {path: 'view-question-century/:page', component: SkillCenturyViewQuestionCenturyComponent},
                            {path: 'create-question-century', component: SkillCenturyCreateQuestionCenturyComponent},
                            {
                                path: 'skill-create-answer-question/:id',
                                component: SkillCenturyAnswerByQuestionComponent
                            },
                            {
                                path: 'create-answer-quetion/:id/:question',
                                component: AnswerQuestionCenturyCreateComponent
                            },
                            {path: 'import-question-century', component: SkillCenturyImportQuestionCenturyComponent},
                        ]
                    },
                    {
                        path: 'skill-inee',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: '',
                                redirectTo: '/admin/skill-inee/index',
                                pathMatch: 'full',
                                canActivate: [AuthGuard]
                            },
                            {path: 'index', component: AdminSkillIneeComponent},
                            {
                                path: 'dimension',
                                canActivateChild: [AuthGuard],
                                children: [
                                    {path: 'create', component: AdminDimensionCreateComponent}
                                ]
                            },
                            {
                                path: 'parameter',
                                canActivateChild: [AuthGuard],
                                children: [
                                    {path: 'create/:id', component: AdminCreateParameterComponent}
                                ]
                            },
                            {
                                path: 'indicator',
                                canActivateChild: [AuthGuard],
                                children: [
                                    {path: 'create/:id', component: AdminIndicatorCreateComponent}
                                ]
                            },
                            {path: 'import', component: AdminImportIneeComponent}
                        ]
                    },
                    {
                        path: 'inee',
                        canActivateChild: [AuthGuard],
                        children: [
                            {
                                path: 'evaluation',
                                canActivateChild: [AuthGuard],
                                children: [
                                    {
                                        path: '',
                                        redirectTo: '/admin/inee/evaluation/index',
                                        pathMatch: 'full',
                                        canActivate: [AuthGuard]
                                    },
                                    {path: 'index', component: AdminIneeEvaluationComponent},
                                    {path: 'create', component: AdminIneeEvaluationCreateComponent},
                                    {path: 'import', component: AdminIneeEvaluationImportComponent},
                                    {path: 'update/:id', component: AdminIneeEvaluationUpdateComponent}
                                ]

                            }
                        ]
                    }

                ]
            }
        ])
    ],
    exports: [
        RouterModule
    ],
    providers: [AuthGuard, AuthService]
})
export class AdminRoutingModule {
}