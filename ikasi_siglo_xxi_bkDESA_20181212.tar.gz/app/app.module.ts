import {NgModule}                   from '@angular/core';
import {BrowserModule}              from '@angular/platform-browser';
import {FormsModule}                from '@angular/forms';
import {AppComponent}               from './app.component';
import {HttpModule, JsonpModule}    from '@angular/http';
// Importamos la configuración de las rutas
import {AppRoutingModule}           from './app.routing';
// Importamos los componentes
import {LogoutComponent}            from './components/logout.component';
import {RegisterComponent}          from './components/register.component';
import {DefaultComponent}           from './components/default.component';
import {ConfirmationComponent}      from './components/confirmation.component';
import {ActivateComponent}          from './components/activate.component';
import {ContactComponent}           from './components/contact.component';
import {NotFoundComponent}          from './components/not-found.component';
import {LoginComponent}             from './components/login.component';
import {UnauthorizedComponent}      from './components/unauthorized.component';
import {APP_CONFIG, AppConfig}      from './app.config';
import {SuggestedCourseComponent}   from "./components/suggested-course.component";
import {PasswordRecoveryComponent}  from "./components/password-recovery.component";
import {SimpleNotificationsModule}  from "angular2-notifications/src/simple-notifications.module";
import {NewPasswordComponent}       from "./components/new-password.component";
import {ApplyCenturyEvaluation}		from "./components/apply-evaluation/apply-century-evaluation.component";
import {ApplyCenturyEvaluating}		from "./components/apply-evaluation/apply-century-evaluating.component";
import {ProfileComponent}           from "./components/profile.component";
import {CheckComponent} from "./components/check.component";
import {ChartsModule} from "ng2-charts";
import {EvaluationTeacherComponent} from "./components/inee/evaluation-teacher.component";
import {QuestionnaireIneeComponent} from "./components/inee/questionnaire-inee.component";


@NgModule({
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpModule,
        JsonpModule,
        SimpleNotificationsModule,
        ChartsModule
    ],
    declarations: [
        AppComponent,
        LogoutComponent,
        LoginComponent,
        RegisterComponent,
        DefaultComponent,
        ConfirmationComponent,
        ActivateComponent,
        ContactComponent,
        NotFoundComponent,
        UnauthorizedComponent,
        SuggestedCourseComponent,
        PasswordRecoveryComponent,
        NewPasswordComponent,
		ApplyCenturyEvaluation,
		ApplyCenturyEvaluating,
        ProfileComponent,
        CheckComponent,
        EvaluationTeacherComponent,
        QuestionnaireIneeComponent
    ],
    bootstrap: [AppComponent],
    providers: [
        {
            provide: APP_CONFIG, useValue: AppConfig
        }
    ]
})

export class AppModule {
}
