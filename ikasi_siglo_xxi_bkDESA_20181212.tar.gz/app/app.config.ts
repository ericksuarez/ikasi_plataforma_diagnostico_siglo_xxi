import {OpaqueToken} from "@angular/core";

export let APP_CONFIG = new OpaqueToken("app.config");

export const ENVIRONMENT = {
    production: true
};

export interface IAppConfig {
    apiEndPoint: string,
    apiEndPointUploads: string
}

export const AppConfig: IAppConfig = {
    apiEndPoint : "https://sinadep.diagnosticosxxi.org",
    apiEndPointUploads : "https://sinadep.diagnosticosxxi.org/uploads/"
    // apiEndPoint : "http://api.sinadep.local",
    // apiEndPointUploads : "http://api.sinadep.local/uploads/"
};
