<?php

namespace AppBundle\Services {

    use BackendBundle\Entity\AnswerIneeTeacher;
    use Doctrine\ORM\EntityManager;

    /**
     * Created by PhpStorm.
     * User: aldorodriguez
     * Date: 17/09/17
     * Time: 15:57
     */
    class IneeResults
    {
        /**
         * @var EntityManager $manager
         */
        private $manager;

        /**
         * AccessControl constructor.
         * @param EntityManager $manager
         */
        public function __construct(EntityManager $manager)
        {
            $this->manager = $manager;
        }

        public function run($teacher)
        {
            $answers = $this->manager->getRepository(AnswerIneeTeacher::class)->findBy([
                'teacher' => $teacher
            ]);

            $dimensions = [];
            $ideal = ['data' => [], 'label' => 'Porcentaje ideal'];
            $user = ['data' => [], 'label' => $teacher->getFullname()];
            $vulnerable = [];
            $count = 0;
            $countDimension = 1;

            foreach ($answers as $key => $answer) {
                if ($answer->getEvaluationInee()->getCorrectAnswer()->getId() === $answer->getAnswerInee()->getId()) {
                    $count++;
                }

                if (array_key_exists($key + 1, $answers)) {
                    if ($answer->getDimension()->getName() !== $answers[$key + 1]->getDimension()->getName()) {
                        array_push($user['data'], $count);
                        array_push($dimensions, "Dimensión " . $countDimension++);
                        array_push($ideal['data'], $answer->getTotal());
                        if($count != $answer->getTotal()) {
                            array_push($vulnerable, $answer->getDimension()->getId());
                        }
                        $count = 0;
                    }
                } else {
                    array_push($user['data'], $count);
                    array_push($dimensions, "Dimensión " . $countDimension++);
                    array_push($ideal['data'], $answer->getTotal());
                    if($count != $answer->getTotal()) {
                        array_push($vulnerable, $answer->getDimension()->getId());
                    }
                }
            }

            return [
                'dimensions' => $dimensions,
                'data' => [$ideal, $user],
                'vulnerable' => $vulnerable
            ];
        }
    }
}