<?php

namespace AppBundle\Controller {

    use BackendBundle\Entity\Course;
    use BackendBundle\Entity\Dimension;
    use Symfony\Bundle\FrameworkBundle\Controller\Controller;
    use Symfony\Component\HttpFoundation\Request;

    /**
     * Created by PhpStorm.
     * User: aldorodriguez
     * Date: 09/11/16
     * Time: 18:01
     */
    class CourseController extends Controller
    {
        const UNAUTHORIZED = 401;

        /**
         * Devuelve todos los cursos registrados
         * @param Request $request
         * @return mixed
         */
        public function indexAction(Request $request)
        {
            // Servicio Helpers
            $helpers = $this->get("app.helpers");
            // Servicio del JWT
            $jwt_auth = $this->get("app.jwt_auth");
            // Control de acceso
            $access_control = $this->get("app.access_control");

            $check = $jwt_auth->isAuthorizedToChange($request, $access_control);

            if (is_array($check)) {
                return $helpers->json($check);
            }

            $page = $request->query->getInt("page", 1);
            $paginator = $this->get("knp_paginator");
            $items_per_page = 10;

            $repository = $this->getDoctrine()->getRepository('BackendBundle:Course');

            /** @noinspection PhpUndefinedMethodInspection */
            $query = $repository->createQueryBuilder('t')
                ->select(['t.id', 't.name', 't.createTime'])
                ->getQuery();

            $pagination = $paginator->paginate($query, $page, $items_per_page);
            /** @noinspection PhpUndefinedMethodInspection */
            $total_items = $pagination->getTotalItemCount();

            return $helpers->json([
                'total_items' => $total_items,
                'page_actual' => $page,
                'items_per_page' => $items_per_page,
                'total_pages' => ceil($total_items / $items_per_page),
                'data' => $pagination
            ]);
        }

        /**
         * Agrega un nuevo curso
         * @param Request $request
         * @return mixed
         */
        public function createAction(Request $request)
        {
            $helpers = $this->get("app.helpers");
            $jwtAuth = $this->get("app.jwt_auth");
            $access_control = $this->get("app.access_control");
            $check = $jwtAuth->isAuthorizedToChange($request, $access_control);

            if (is_array($check)) {
                return $helpers->json($check);
            }

            $params = json_decode($request->get("json", null));

            if(!empty($params)) {
                $name = (property_exists($params, "name")) ? $params->name : null;
                $description = (property_exists($params, "description")) ? $params->description : null;
                $link = (property_exists($params, "link")) ? $params->link : null;
                $teacher_function = (property_exists($params, "teacher_function")) ? $params->teacher_function : null;
                $education_level = (property_exists($params, "education_level")) ? $params->education_level : null;
                $specialty = (property_exists($params, "specialty")) ? $params->specialty : null;
                $type_suggestion = (property_exists($params, "type_suggestion")) ? $params->type_suggestion : null;
                $skill_century = (property_exists($params, "skill_century")) ? $params->skill_century : null;
                $area_century = (property_exists($params, "area_century")) ? json_encode($params->area_century) : null;
                $dimension = (property_exists($params, "dimension")) ? $params->dimension : null;
                $validator = $this->get('validator');
                $course = new Course();
                $course->setName($name)
                    ->setDescription($description)
                    ->setLink($link)
                    ->setEducationLevel($this->getDoctrine()->getRepository('BackendBundle:EducationLevel')->find($education_level))
                    ->setSpeciality($this->getDoctrine()->getRepository('BackendBundle:Speciality')->find($specialty))
                    ->setTeacherFunction($this->getDoctrine()->getRepository('BackendBundle:TeacherFunction')->find($teacher_function))
                    ->setTypeSuggestion($type_suggestion)
                    ->setCreateTime(new \DateTime('now'));

                if(!empty($skill_century)) {
                    $course->setSkillCentury($this->getDoctrine()->getRepository('BackendBundle:SkillCentury')->find($skill_century))
                        ->setAreaCenturyIds($area_century);
                }

                if(isset($dimension)) {
                    $course->setDimension($this->getDoctrine()->getRepository(Dimension::class)->find($dimension));
                }


                if (count($validator->validate($course)) == 0) {
                    $manager = $this->getDoctrine()->getManager();
                    $manager->persist($course);
                    $manager->flush();
                    return $helpers->json([
                        'status' => 'success',
                        'title' => 'Guardado',
                        'message' => '¡Los datos se guardaron correctamente!',
                        'id' => $course->getId()
                    ]);
                }
            }

            return $helpers->json(array(
                'status' => 'error',
                'title' => 'Error',
                'message' => 'Error al guardar el curso'
            ));
        }

        /**
         * Devuelve la información de un curso
         * @param Request $request
         * @param $id
         * @return mixed
         */
        public function viewAction(Request $request, $id)
        {
            $helpers = $this->get("app.helpers");
            $jwtAuth = $this->get("app.jwt_auth");
            $access_control = $this->get("app.access_control");
            $check = $jwtAuth->isAuthorizedToChange($request, $access_control);

            if (is_array($check)) {
                return $helpers->json($check);
            }

            if(empty($id)) {
                return $helpers->json(array(
                    'status' => 'error',
                    'title' => 'Error',
                    'message' => 'Error al obtener el curso'
                ));
            }

            return $helpers->json($this->getDoctrine()->getRepository('BackendBundle:Course')->find($id));
        }

        /**
         * Actualiza la información de un curso
         * @param Request $request
         * @param $id
         * @return mixed
         */
        public function updateAction(Request $request, $id)
        {
            $helpers = $this->get("app.helpers");
            $jwtAuth = $this->get("app.jwt_auth");
            $access_control = $this->get("app.access_control");
            $check = $jwtAuth->isAuthorizedToChange($request, $access_control);

            if (is_array($check)) {
                return $helpers->json($check);
            }

            $params = json_decode($request->get("json", null));

            if(!empty($params)) {
                $name = (property_exists($params, "name")) ? $params->name : null;
                $description = (property_exists($params, "description")) ? $params->description : null;
                $link = (property_exists($params, "link")) ? $params->link : null;
                $teacher_function = (property_exists($params, "teacher_function")) ? $params->teacher_function : null;
                $education_level = (property_exists($params, "education_level")) ? $params->education_level : null;
                $specialty = (property_exists($params, "specialty")) ? $params->specialty : null;
                $type_suggestion = (property_exists($params, "type_suggestion")) ? $params->type_suggestion : null;
                $skill_century = (property_exists($params, "skill_century")) ? $params->skill_century : null;
                $area_century = (property_exists($params, "area_century")) ? json_encode($params->area_century) : null;
                $dimension = (property_exists($params, "dimension")) ? $params->dimension : null;
                $validator = $this->get('validator');

                $course = $this->getDoctrine()->getRepository('BackendBundle:Course')->find($id);
                $course->setName($name)
                    ->setDescription($description)
                    ->setLink($link)
                    ->setEducationLevel($this->getDoctrine()->getRepository('BackendBundle:EducationLevel')->find($education_level))
                    ->setSpeciality($this->getDoctrine()->getRepository('BackendBundle:Speciality')->find($specialty))
                    ->setTeacherFunction($this->getDoctrine()->getRepository('BackendBundle:TeacherFunction')->find($teacher_function))
                    ->setTypeSuggestion($type_suggestion)
                    ->setUpdateTime(new \DateTime('now'));

                if(!empty($skill_century)) {
                    $course->setSkillCentury($this->getDoctrine()->getRepository('BackendBundle:SkillCentury')->find($skill_century))
                        ->setAreaCenturyIds($area_century);
                }

                if(isset($dimension)) {
                    $course->setDimension($this->getDoctrine()->getRepository(Dimension::class)->find($dimension));
                }

                if (count($validator->validate($course)) == 0) {
                    $manager = $this->getDoctrine()->getManager();
                    $manager->persist($course);
                    $manager->flush();
                    return $helpers->json([
                        'status' => 'success',
                        'title' => 'Guardado',
                        'message' => '¡Los datos se guardaron correctamente!'
                    ]);
                }
            }

            return $helpers->json(array(
                'status' => 'error',
                'title' => 'Error',
                'message' => 'Error al guardar el curso'
            ));
        }

        /**
         * Devuelve las sugerencias de cursos badado en habilidades de siglo XXI
         * @param Request $request
         * @return mixed
         */
        public function suggestionsAction(Request $request)
        {
            $helpers = $this->get('app.helpers');
            $jwtAuth = $this->get("app.jwt_auth");
            $suggestions = $this->get('app.suggestions');

            $authorization = $request->headers->get('X-API-KEY');
            $identity = $jwtAuth->checkToken($authorization, true);

            if (!$identity) {
                return $helpers->json(['status' => 'error', 'code' => $this::UNAUTHORIZED, 'message' => 'Unauthorized']);
            }

            return $helpers->json($suggestions->run($identity->teacher_id));
        }

        /**
         * Actuliza la imagen de un curso
         * @param Request $request
         * @param $id
         * @return mixed
         */
        public function uploadAction(Request $request, $id)
        {
            $helpers = $this->get("app.helpers");
            $jwtAuth = $this->get("app.jwt_auth");
            $access_control = $this->get("app.access_control");
            $check = $jwtAuth->isAuthorizedToChange($request, $access_control);

            if (is_array($check)) {
                return $helpers->json($check);
            }

            $manager = $this->getDoctrine()->getManager();

            $course = $manager->getRepository('BackendBundle:Course')->find($id);

            if(!is_object($course)) {
                return $helpers->json(['status' => 'error', 'code' => $this::UNAUTHORIZED, 'message' => 'Unauthorized']);
            }

            $file = $request->files->get('image', null);

            if(!empty($file)) {
                $ext = $file->guessExtension();
                $fileName = time() . "." . $ext;
                $path = "uploads/courses";
                $file->move($path, $fileName);
                /** @noinspection PhpUndefinedMethodInspection */
                $course->setImage($fileName);

                $manager->persist($course);
                $manager->flush();
                return $helpers->json([
                    'status' => 'success',
                    'title' => 'Guardado',
                    'message' => '¡El archivo se ha subido correctamente!'
                ]);
            }

            return $helpers->json([
                'status' => 'error',
                'title' => 'Error',
                'message' => 'Error al guardar la imagen'
            ]);
        }
    }
}